package com.me.mygdxgame.Screen;

import com.me.mygdxgame.Hourglass;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;

public class EndingScreen extends BaseScreen
{
	private Skin skin;
	private Label credits;
	private Table table;
	private Stage stage;
	
	public EndingScreen(Hourglass game){
		super(game);
		skin = new Skin(Gdx.files.internal("Font/uiskin.json"));
		credits = new Label("The End"+'\n'+" "+'\n'+"Programmed && Designed"+
		'\n'+"T. Enrique T. Amador."+'\n'+" "+'\n'+" "+"Sound && Sprite"+'\n'+"TLOZ(alttp)",skin);
		table = new Table();
		table.setFillParent(true);
		table.center();
		table.add(credits);
		stage = new Stage();
		stage.addActor(table);
	}

	@Override
	public void render(float p1)
	{
		game.getViewport().apply();
		stage.draw();
	}

	@Override
	public void resize(int p1, int p2)
	{
		game.getViewport().update(p1,p2);
	}
	
}
