package com.me.mygdxgame.Screen;
import com.me.mygdxgame.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.utils.viewport.*;

public class StartingScreen extends BaseScreen
{
	private Skin skinTitle;
	private int delta;
	private Texture texture;
	private TextureRegion backgroundTexture;
	private OrthographicCamera camera;
	private Label head;
	private Label title;
	private Label signed;
	private Label touchScreen;
	private Table view;
	private Table viewTouch;
	private Stage stage;
	//private FitViewport viewport;
	
	public StartingScreen(Hourglass game){
		super(game);
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 400, 800 * Gdx.graphics.getHeight() / Gdx.graphics.getWidth());
		//viewport = new FitViewport(game.V_WIDTH,game.V_HEIGHT);
		texture = new Texture(Gdx.files.internal("skyBackground.png"));
        backgroundTexture = new TextureRegion(texture, 0, 0, 2048, 563);
		skinTitle = new Skin(Gdx.files.internal("Font/uiskin.json"));
		view = new Table();
		viewTouch = new Table();
		stage = new Stage();
		title = new Label("Hourglass",skinTitle);
		title.setFontScale(4,3);
		title.setColor(Color.RED);
		head = new Label("The first of",skinTitle);
		head.setFontScale(2,1);
		head.setColor(Color.WHITE);
		touchScreen = new Label("Touch Screen",new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		touchScreen.setFontScale(2,1);
		touchScreen.setColor(Color.YELLOW);
		signed = new Label("Henriqu TA"+'\n'+"2018 - 2019©",new Label.LabelStyle(new BitmapFont(),Color.WHITE));
		signed.setFontScale(2,1);
		signed.setColor(Color.WHITE);
		//viewport.apply();
		game.getViewport().apply();
		
		view.setFillParent(true);
		//view.debug();
		view.center();
		view.add(head);
		view.row();
		view.add(title);
		
		viewTouch.setFillParent(true);
		//viewTouch.debug();
		viewTouch.center().align(100);
		viewTouch.add(signed);
		viewTouch.row();
		viewTouch.add(touchScreen);
		
		stage.addActor(view);
		stage.addActor(viewTouch);
	}

	@Override
	public void render(float p1)
	{
		Gdx.gl.glClearColor(0f, 0f, 0f, 0f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		//viewport.apply();
		game.getViewport().apply();
		SequenceAction act = new SequenceAction();
		if(delta < 200)delta++;
		else if(delta == 200) delta = 0;
		if(delta == 0){
			act.addAction(Actions.fadeOut(1));
			act.addAction(Actions.fadeIn(1));
		}
		touchScreen.addAction(act);
		camera.update();
	
		if(camera.position.x < 790)
		camera.position.x += 1;
		game.getDrawer().setProjectionMatrix(camera.combined);
		game.getDrawer().begin();
		game.getDrawer().draw(texture,0,0,stage.getWidth(),stage.getHeight());
		game.getDrawer().end();
		
		if(camera.position.x > 505){
			stage.draw();
			if(Gdx.input.justTouched()){
				game.setToSelectMatch();
				return;
			}
			
			}
		stage.act();
	}

	@Override
	public void resize(int p1, int p2)
	{
		//viewport.update(p1,p2);
		game.getViewport().update(p1,p2);
	}

	@Override
	public void hide()
	{
		//game.getDrawer().dispose();
		skinTitle.dispose();
		texture.dispose();
	}

}


