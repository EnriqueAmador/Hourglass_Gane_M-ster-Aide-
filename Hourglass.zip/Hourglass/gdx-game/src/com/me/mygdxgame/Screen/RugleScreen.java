package com.me.mygdxgame.Screen;
import com.me.mygdxgame.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.graphics.*;

public class RugleScreen extends BaseScreen
{
	private Table table;
	private Fairy fairy;
	private Dialog_Box dialogBox;
	private Stage stage;
	
	public RugleScreen(Hourglass game){
		super(game);
		table = new Table();
		fairy = new Fairy();
		dialogBox = new Dialog_Box(game);
		dialogBox.setSize(704,104);
		fairy.setSize(180,180);
		table.setFillParent(true);
		table.center();
		table.add(fairy).center();
		table.row();
		table.add().size(80,80);
		table.row();
		table.add(dialogBox);
		stage = new Stage();
		stage.addActor(table);
	}

	@Override
	public void render(float p1)
	{
		game.getViewport().apply();
		stage.act();
		stage.draw();
	}

	@Override
	public void resize(int p1, int p2)
	{
		game.getViewport().update(p1,p2);
	}

}

class Dialog_Box extends Actor{
	
	private Texture dialog_box;
	private BitmapFont font;
	private Texture box;
	private int timeDialog,timeCrease = 1;
	private int indexDialog;
	private int indexDialog1;
	private String[] dialog = {
		"E","s","t","e"," ","J","u","e","g","o"," ","E","s"," ",
		"D","e"," ","L","i","m","i","t","e"," ","D","e"," ",
		"T","i","e","m","p","o"," ","L","o","s"," ","I","t","e","m","s"," ",
		"N","o"
		
	};
	private String[] dialog1 = {
		"","S","e"," ","R","e","c","a","r","g","a","n"," ","Y"," ",
		"P","u","e","d","e","n"," ","M","o","v","e","r","s","e"," ",
		"¡S","U","E","R","T","E!"
	};
	private String dialogBox = dialog[0];
	private String dialogBox1 = "";
	private Hourglass game;
	
	public Dialog_Box(Hourglass game){
		this.game = game;
		dialog_box = Hourglass.manager.get("dialog_box.png",Texture.class);
		font = new BitmapFont();
		box = Hourglass.manager.get("box.png",Texture.class);
	}

	@Override
	public void draw(Batch batch, float parentAlpha)
	{
		//batch.draw(box,getX()+10,getY()+74,16,16);
		//game.getDrawer().begin();
		timeDialog++;
		if((timeDialog == timeCrease)&&(indexDialog < 45)){
			indexDialog += 1;
			//if(indexDialog == 42)
				//dialogBox = dialogBox + dialog[42];
				//else
			dialogBox = dialogBox + dialog[indexDialog];
		//for(String message : dialog)
			//dialogBox = message;
		timeCrease += 10;
		}
		if((timeDialog == timeCrease)&&(indexDialog == 45 && indexDialog1 < 35)){
			indexDialog1 += 1;
			dialogBox1 = dialogBox1 + dialog1[indexDialog1];
			timeCrease += 10;
		}
	
		if((indexDialog1 == 35)&&(Gdx.input.justTouched()))
			game.setGamePlayScreen();
		
		font.setScale(2,2);
		font.draw(batch,dialogBox,getX()+15,getY()+86);
		font.draw(batch,dialogBox1,getX()+15,getY()+54);
		//timeCrease += 100;
		//}
		//game.getDrawer().end();
		batch.draw(dialog_box,getX(),getY(),704,104);
	}
	
}

class Fairy extends Actor
{
	private Animation_Graphics sprite;
	private TextureRegion[] fairy;
	private TextureRegion texture;
	private Animation anim;
	private float time;

	public Fairy(){
		sprite = new Animation_Graphics("fairy.png");
		fairy = sprite.atlas(3,0,0,32,32);
		anim = new Animation(0.17f,fairy);
	}
	
	@Override
	public void draw(Batch batch, float parentAlpha)
	{
	    time += Gdx.graphics.getDeltaTime();
        texture = anim.getKeyFrame(time,true);
        batch.draw(texture,getX(),getY(),180,180);
	}

}
