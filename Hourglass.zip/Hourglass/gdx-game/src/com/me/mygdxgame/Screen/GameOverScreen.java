package com.me.mygdxgame.Screen;
import com.me.mygdxgame.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;

public class GameOverScreen extends BaseScreen
{
	private int appears;
	private Skin skin;
	private Label gameOver;
	private Table table;
	private Stage stage;
	
	public GameOverScreen(Hourglass game){
		super(game);
		skin = new Skin(Gdx.files.internal("Font/uiskin.json"));
		gameOver = new  Label("Game Over",skin);
		table = new Table();
		table.setFillParent(true);
		table.center();
		table.add(gameOver);
		stage = new Stage();
		stage.addActor(table);
	}

	@Override
	public void render(float p1)
	{
		appears++;
		SequenceAction act = new SequenceAction();
		if(appears == 2){
		act.addAction(Actions.fadeOut(3));
		act.addAction(Actions.fadeIn(3));
		}
		game.getViewport().apply();
		gameOver.addAction(act);
		stage.draw();
		stage.act();
		
		if(Gdx.input.justTouched())
			game.setToSelectMatch();
	}
	
	@Override
	public void resize(int p1, int p2)
	{
		//viewport.update(p1,p2);
		game.getViewport().update(p1,p2);
	}
	

}
