package com.me.mygdxgame.Screen;

import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.me.mygdxgame.*;
import com.badlogic.gdx.utils.viewport.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.me.mygdxgame.Systems.Animation.*;

public class LoadScreen extends BaseScreen
{
	private Skin skin;
	private LoadingWitch witch;
	private Label loading;
	private Table viewport;
	private Stage stage;
	
	public LoadScreen(Hourglass game){
		super(game);
	}
	
	@Override
	public void show()
	{
		viewport = new Table();
		stage = new Stage();
        skin = new Skin(Gdx.files.internal("Font/uiskin.json"));

		witch = new LoadingWitch();
		witch.setSize(80,80);
        loading = new Label("Loading...", skin);
		viewport.setFillParent(true);
		//viewport.debug();
		viewport.center();
		viewport.add(witch).center();
		viewport.row();
		viewport.add().size(20,20);
		viewport.row();
		viewport.add(loading);
       
		stage.addActor(viewport);
	}

	@Override
	public void render(float p1)
	{
		if (game.manager.update()) {
            game.finishLoading();
        } else {
            int progress = (int) (game.manager.getProgress() * 100);
            loading.setText("Loading... " + progress + "%");
        }

        stage.act();
        stage.draw();
	}

}

class LoadingWitch extends Actor
{
	Animation_Graphics sprite;
	TextureRegion[] witch;
	TextureRegion texture;
	Animation anim;
	float time;
	
	public LoadingWitch(){
		sprite = new Animation_Graphics("witch.png");
		witch = sprite.atlas(8,0,0,32,40);
		anim = new Animation(0.05f,witch);
	}
	
	@Override
	public void draw(Batch batch, float parentAlpha)
	{
	    time += Gdx.graphics.getDeltaTime();
        texture = anim.getKeyFrame(time,true);
        batch.draw(texture,getX(),getY(),80,80);
	}
	
}
