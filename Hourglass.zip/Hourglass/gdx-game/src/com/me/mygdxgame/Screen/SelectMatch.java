package com.me.mygdxgame.Screen;
import com.me.mygdxgame.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton.ImageButtonStyle;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton.ButtonStyle;
import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.utils.viewport.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.graphics.g2d.*;

public class SelectMatch extends BaseScreen
{
	//private FitViewport viewport;
	private Skin style;
	private Label match;
	private String name;
	private BitmapFont font;
	private TextureRegion styleButton;
	private TextField field;
	private TextButton delete;
	private Table view,messenge;
	private Stage stage;
	
	public SelectMatch(final Hourglass game){
		super(game);
		//viewport = new FitViewport(game.V_WIDTH,game.V_HEIGHT);
		font = new BitmapFont();
		style = new Skin(Gdx.files.internal("Font/uiskin.json"));
		styleButton = new TextureRegion(Hourglass.manager.get("icon_load.png", Texture.class));
		TextureRegionDrawable buttonDrawable = new TextureRegionDrawable(styleButton);
		ImageButtonStyle imageStyle = new ImageButtonStyle(style.get(ButtonStyle.class));
		imageStyle.imageUp = buttonDrawable;
		ImageButton load = new ImageButton(imageStyle);
		//help.setStyle(style.get(ImageButton.ButtonStyle.class));
		game.getViewport().apply();
		match = new Label("Elige Un Archivo",style);
		field = new TextField("",style);
		delete = new TextButton("Delete",style);
		messenge = new Table();
		messenge.setFillParent(true);
		messenge.top().left();
		messenge.add(match);
		view = new Table();
		view.setFillParent(true);
		//view.debug();
		view.center();
		view.add(field).size(400,50);
		view.row();
		view.add().size(30,30);
		view.row();
		view.add(load).size(100,100);
		view.row();
		view.add().size(30,30);
		view.row();
		view.add(delete).size(100,100);
		/*info = new Table();
		info.setFillParent(true);
		info.top().right();
		info.add(help).size(80,80);*/
		stage = new Stage();
		stage.addActor(messenge);
		//stage.addActor(info);
		stage.addActor(view);
		Gdx.input.setInputProcessor(stage);
		
		load.addListener(new ChangeListener(){
			@Override
			public void changed(ChangeEvent event,Actor actor){
				game.file = field.getText();
				game.setGameRugleScreen();
				/*view.addAction(Actions.sequence(Actions.delay(0f),
				Actions.parallel(Actions.moveBy(0,600,0.5f),
				Actions.fadeOut(0.5f))));*/
				
			}
			});
			
		delete.addListener(new ChangeListener(){
				@Override
				public void changed(ChangeEvent event,Actor actor){
					game.deleteFiles = field.getText();
					game.setGameRugleScreen();
					/*view.addAction(Actions.sequence(Actions.delay(0f),
					 Actions.parallel(Actions.moveBy(0,600,0.5f),
					 Actions.fadeOut(0.5f))));*/

				}
			});
	}

	@Override
	public void render(float p1)
	{
		game.getViewport().apply();
		name = field.getText();
		//game.getDrawer().begin();
		//font.draw(game.getDrawer(),"Text:" + game.getDataBases().get(),200,200);
		//game.getDrawer().end();
		stage.act();
		stage.draw();
	}

	@Override
	public void resize(int p1, int p2)
	{
		game.getViewport().update(p1,p2);
	}
	
}
