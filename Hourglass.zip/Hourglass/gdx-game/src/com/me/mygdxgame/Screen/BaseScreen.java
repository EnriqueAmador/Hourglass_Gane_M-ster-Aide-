package com.me.mygdxgame.Screen;
import com.badlogic.gdx.*;
import com.me.mygdxgame.*;

public class BaseScreen implements Screen
{
	protected Hourglass game;
	
	public BaseScreen(Hourglass game){
		this.game = game;
	}

	@Override
	public void show()
	{
		// TODO: Implement this method
	}

	@Override
	public void render(float p1)
	{
		// TODO: Implement this method
	}

	@Override
	public void hide()
	{
		// TODO: Implement this method
	}

	@Override
	public void resize(int p1, int p2)
	{
		// TODO: Implement this method
	}

	@Override
	public void resume()
	{
		// TODO: Implement this method
	}

	@Override
	public void pause()
	{
		// TODO: Implement this method
	}

	@Override
	public void dispose()
	{
		// TODO: Implement this method
	}

}
