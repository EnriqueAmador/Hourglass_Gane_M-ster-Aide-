package com.me.mygdxgame.Screen;

import com.me.mygdxgame.Hourglass;
import com.me.mygdxgame.Actors.Heroe;
import com.me.mygdxgame.Systems.Input.Input_GamePad;
import com.me.mygdxgame.Systems.Hud.Hud;
import com.me.mygdxgame.Systems.Hud.Map_Handler;
import com.me.mygdxgame.Systems.Entity.Base_Enemies;
import com.me.mygdxgame.Systems.Entity.EnemyCreator;
import com.me.mygdxgame.Systems.Mixed.Mixed;
import com.me.mygdxgame.Systems.Camera.OrthoCamera;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.FitViewport;
import org.enriqu.ta.SYSTEMS.Input.*;
import com.me.mygdxgame.Actors.Items.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;
import com.badlogic.gdx.graphics.g3d.decals.*;
import com.badlogic.gdx.*;

public class GameScreen extends BaseScreen
{
	private TiledMap map;
	public Preferences pref;
	private String nameFile;
	private int x,y;
	private OrthogonalTiledMapRenderer renderer;
	private SpriteBatch sb;
	private Heroe player;
	private Hud hud;
	private EnemyCreator creator;
	private Mixed mix;
	private BitmapFont font;
	private Input_GamePad pad;
    private Map_Handler miniMap;
	private OrthoCamera camera;
	private Stage stage;
	private FitViewport viewport;
	private ExtendViewport vPad;

	public GameScreen(Hourglass game)
	{
		super(game);
		sb = new SpriteBatch();
		font = new BitmapFont();
		map = new TmxMapLoader().load("Map/World.tmx");
		renderer = new OrthogonalTiledMapRenderer(map);
		
		pref = Gdx.app.getPreferences(game.file);
		pref.clear();
		nameFile = game.file;
		
		x = pref.getInteger("AxisX",43);
		y = pref.getInteger("AxisY",3);
		
		player = new Heroe(map,x,y);
		hud = new Hud(game,pref.getInteger("Magic",180),
		pref.getInteger("Heart",5),pref.getInteger("Arrow",10),
		pref.getInteger("Key",0),pref.getInteger("Minute",0));
		creator = new EnemyCreator(this,map);
		pad = new Input_GamePad(game);
		mix = new Mixed(map);
		camera = new OrthoCamera(map,player);
		miniMap = new Map_Handler(player);
		
		player.pixX = pref.getInteger("PixX",43);
		player.pixY = pref.getInteger("PixY",96);
		player.camX = pref.getFloat("CamX",player.pixX+305);
		player.camY = pref.getFloat("CamY",player.pixY);
		
		viewport = new FitViewport(game.V_WIDTH,game.V_HEIGHT);
		vPad = new ExtendViewport(game.V_WIDTH/game.PPM,game.V_HEIGHT/game.PPM);
		
		stage = new Stage(viewport);
	}

	@Override
	public void render(float delta)
	{
		Gdx.gl.glClearColor(0f, 0f, 0f, 0f);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		viewport.apply();
		//game.manager.get("Sound/overworld.mp3", Music.class).play();
		camera.getOrthocam();
		camera.getOrthocam().update();
		renderer.setView(camera.getOrthocam());
		game.getDrawer().setProjectionMatrix(camera.getOrthocam().combined);
		player.batch().setProjectionMatrix(camera.getOrthocam().combined);
		renderer.render();
		
		/*player.batch().begin();
		player.batch().draw(player.drawPlayer(game),(int)player.getX() - player.rePosX,(int)player.getY() - player.resPosY,player.resX,player.resY);
		player.batch().end();*/
		player.drawPlayer(this,hud,game,pad);
		player.updateDrawer();
	
		creator.setEnemies(game,player,hud,delta);
		mix.draw(game);
		player.updatePlayer();
		player.shoot(game);
		//player.die(hud,pad);
		hud.generateHud();
		miniMap.mini_map(player,game);
		
		if(hud.getKeys() >= 22){
			game.setEndingScreen();
			return;}
		if(player.getGameOverScreen())
			game.setGameOverScreen();
			
		vPad.apply();
		pad.draw(player,hud,game);
		sb.begin();
		debug();
		sb.end();

	}

	public void debug()
	{
        font.setColor(Color.BLUE);
		font.draw(sb, "PlayergetY:" + player.getY()/16, 0, 260);
        font.draw(sb, "PlayergetX:" + player.getX()/16, 0, 280);
        font.draw(sb, "FPS: " + hud.getHeart(), 0, 296);
        font.draw(sb, "camera: " + creator.x,0, 315);

	}

	@Override
	public void resize(int width, int height) 
	{
		viewport.update(width,height);
		vPad.update(width,height);
		pad.getStage().getViewport().update(width,height);
		miniMap.resize();
	}

	@Override
	public void show()
	{
		
	}

	@Override
	public void hide()
	{
		pref.clear();
	}

    
	@Override
	public void pause()
	{
		pref.putInteger("AxisX",(int)player.getX()/16);
		pref.putInteger("AxisY",(int)player.getY()/16);
		pref.putInteger("Magic",hud.lessMagic);
		pref.putInteger("Heart",hud.lessHeart);
		pref.putInteger("Key",hud.addHudKey());
		pref.putInteger("Minute",hud.mins_h);
		pref.putInteger("PixX",miniMap.getPixX(player));
		pref.putInteger("PixY",miniMap.getPixY(player));
		pref.putFloat("CamX",miniMap.getCamX(player));
		pref.putFloat("CamY",miniMap.getCamY(player));
		pref.putInteger("Arrow",hud.getStateArrow());
		pref.putBoolean("Death",player.getGameOverScreen());
		pref.flush();
		
	}

	@Override
	public void resume()
	{
		
	}

	@Override
	public void dispose()
	{
		font.dispose();
		sb.dispose();
		player.batch().dispose();
		renderer.dispose();
		hud.dispose();
		player.disposeAllTexture(game);
		miniMap.clearPixmap();
		game.dispose();
		
	}

}
