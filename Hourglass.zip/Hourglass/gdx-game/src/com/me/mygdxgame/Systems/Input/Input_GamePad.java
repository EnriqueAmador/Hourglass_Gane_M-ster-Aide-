/*******************************************************************************
 * @ (#) Input_GamePad.java 
 * 
 * Copyright (c) 2017/Diciembre - 2018 Rockbelle(Henriqu TA), Inc.
 * Juigalpa, Chontales, Nicaragua - Bo. Carlos Nuñez, NIC
 *
 * All rights reserved.
 * 
 * Este código esta bajo licencia de GNU, todo uso de este código esta libre
 * salvo a que no se haga con fines ajenos a la ley, tomando en cuenta, las normas
 * y leyes de cada estado, país o región, no se debera usar este código, con fines
 * malvados, a menos de contar con la autorización de su creador.
 *
 * Este proyecto esta desarollado con el Framework de LibGdx's Lib, a si mismo esta
 * sujeta a sus propias políticas y posibles recursos de terceros.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

package com.me.mygdxgame.Systems.Input;

import org.enriqu.ta.SYSTEMS.Input.Event;
import com.me.mygdxgame.Hourglass;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Touchpad;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;
import com.badlogic.gdx.utils.viewport.*;

/**
 * Esta clace registra y detecta los eventos que ocurren en el juego 
 * desde el presionar un boton y deslizar la perilla del touchpad.
 *
 * @Version           0.2 (1,20-04-2018)
 * @Author            Tomàs E. Téllez A.
 */
public class Input_GamePad extends org.enriqu.ta.SYSTEMS.Input.Event
{
	
	/** Objeto de imagen utilizado para cargar los botones*/
	private Image button_A;
	private Image button_B;
	private Image button_X;
	private Image button_Y;
	private Image button_Z;
	
	/** Objeto de escenario utilizado para establecer el campo de dibujo*/
	private Stage stage;
	
	/** Objeto {@Joystick, touchpad}
	utilizado para obtener características de la palanca*/
	private Joystick jostick;
	private String dir = "Right";
	private int angleRad,point;
	private int roll;
	private int shield;
	private int setRound;

	/**
	* Creado para ser usado con el fin de construir los eventos del juego
	* se creo, para cargar de igual forma los recursos que conyeba.
	*
	* @param Heroe, obejeto utilizado para ser igualado por el obejeto
	* de la misma clace para ser utilizado en toda la clace {this.player = player;}.
	*/
	
	public Input_GamePad(Hourglass game){
	//  Se inicializan los objetos y se establece el procesador de la entrada.
	    stage = new Stage(new ScreenViewport());
		jostick = new Joystick(game);
		Gdx.input.setInputProcessor(stage);
		Table button = new Table();
		Table joystick = new Table();
		button.setFillParent(true);
		joystick.left();
		button_A = new Image(game.manager.get("GamePad/Button_Sword.png",Texture.class));
		button_A.setSize(75, 75);
		
		button_B = new Image(game.manager.get("GamePad/Button_Save.png",Texture.class));
		button_B.setSize(69, 69);
		
		button_X = new Image(game.manager.get("GamePad/Button_Shield.png",Texture.class));
		button_X.setSize(55, 55);
		
		button_Y = new Image(game.manager.get("GamePad/Button_Y.png",Texture.class));
		button_Y.setSize(55, 55);
		
		button_Z = new Image(game.manager.get("GamePad/Button_Z.png",Texture.class));
		button_Z.setSize(55, 55);
		
		addButtonEvent(Type.TOUCH_ANALOG_PICK,Color.DARK_GRAY,button_A,"A");
		addButtonEvent(Type.TOUCH_NORMAL,Color.DARK_GRAY,button_Z,"Z");
		addButtonEvent(Type.TOUCH_PICK,Color.DARK_GRAY,button_B,"B");
		addButtonEvent(Type.TOUCH_ANALOG_PICK,Color.DARK_GRAY,button_Y,"Y");
		addButtonEvent(Type.TOUCH_NORMAL,Color.DARK_GRAY,button_X,"X");
		
		//joystick.debug();
		joystick.align(100).left();
        joystick.add(jostick).size(175,175);

		//button.debug();
		button.align(100).right();
		button.add(button_Z).left();
		button.row();
		button.add(button_Y).left();
		button.row();
		button.add(button_A);
		button.add(button_X).left();
		button.row();
		button.add(button_B).size(58,58).padRight(40);
		
		stage.addActor(button);
		stage.addActor(joystick);
		
		}
		
		/**
		* Utilizado unicamente para dibujar los Ui ingresados al stage
		*/

	public void draw(com.me.mygdxgame.Actors.Heroe player,com.me.mygdxgame.Systems.Hud.Hud hud,Hourglass game){
		inputGame(player,hud,game);
		hud.signalTopArrow();
		stage.act();
		stage.draw();
		addTouchpad(jostick.isTouched());
		//player.updateData(proof);
		if(player.resetIndex){
			interval();
			player.resize();
			nameKey = "isEmpty";
			player.resetIndex = false;
			setRound = touch = 0;}
			
		}
	
		/**
		* Utilizado para detectar los eventos del touchpad
		*/
	private void inputGame(com.me.mygdxgame.Actors.Heroe p,com.me.mygdxgame.Systems.Hud.Hud hud,Hourglass game)
		{  
			Vector2 angle = new Vector2(jostick.getKnobPercentX(),jostick.getKnobPercentY());
			angleRad = (int)angle.angle();

			switch(nameKey){
				case "A":
					setRound++;
					p.setSword = true;
					if(oneTouched(setRound))
						game.manager.get("Sound/Sword1.wav", Sound.class).play();
					switch(dir){
						case "Up":
							p.state = p.state.SwordUp;
							p.stateEffect("Player/LinkAtlasSword.png",45,34);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(270,true,false);
							break;
						case "Down":
							p.state = p.state.SwordDown;
							p.stateEffect("Player/LinkAtlasSword.png",45,34);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(270,true,false);
							break;
						case "Left":
							p.state = p.state.SwordLeft;
							p.stateEffect("Player/LinkAtlasSword.png",45,34);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(270,true,false);
							break;
						case "Right":
							p.state = p.state.SwordRight;
							p.stateEffect("Player/LinkAtlasSword.png",45,34);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(270,true,false);
							break;
					}
					break;
				case "Z":
					setRound++;
					if(Gdx.input.justTouched())
						game.manager.get("Sound/hookshot_set.wav", Sound.class).play();
					switch(dir){
						case "Up":
							p.state = p.state.HookShootUp;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(80,false,true);
							setIntervalTime("Z","HookShot",60);
							break;
						case "Down":
							change(-10,0,0,oneTouched(setRound));
							p.state = p.state.HookShootDown;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							SET_FINISH_FRAME(100,false,true);
							setIntervalTime("Z","HookShot",80);
							break;
						case "Left":
							p.state = p.state.HookShootLeft;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(60,false,true);
							setIntervalTime("Z","HookShot",40);
							break;
						case "Right":
							p.state = p.state.HookShootRight;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(60,false,true);
							setIntervalTime("Z","HookShot",40);
							break;
					}
					break;
				case "X":
					shield++;
					setRound++;
					p.setShield = true;
					if(shield == 1)
						game.manager.get("Sound/shield_out.wav", Sound.class).play();
					switch(dir){
						case "Up":
							p.state = p.state.ShieldUp;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(80,false,false);
							break;
						case "Down":
							p.state = p.state.ShieldDown;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(80,false,false);
							break;
						case "Left":
							p.state = p.state.ShieldLeft;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(40,false,false);
							break;
						case "Right":
							p.state = p.state.ShieldRight;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-10,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(40,false,false);
							break;
					}
					break;
				case "Y":
					point++;
					setRound++;
					change(-10,0,0,oneTouched(setRound));
					if(point == 1)
						hud.downArrow();
					if((Gdx.input.justTouched()&&hud.getStateArrow() + hud.numA < 0)&&point == 1){
						game.manager.get("Sound/bow_twang.wav", Sound.class).play();
						return;}
					if((oneTouched(setRound)&&hud.getStateArrow() + hud.numA > 0)&&point == 1)
						game.manager.get("Sound/bow_pull.wav", Sound.class).play();
					if((oneTouched(setRound)&&hud.getStateArrow() + hud.numA > 0)&&(point == 1&&hud.lessMagic > 0))
						hud.lessMagic -= 30;
					switch(dir){
						case "Up":
							p.state = p.state.BowUp;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							SET_FINISH_FRAME(100,true,false);
							if(getValueFrame() == 100){
								p.way = "Up";
								p.shootArrow(hud,4,16);}
							break;
						case "Down":
							p.state = p.state.BowDown;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							SET_FINISH_FRAME(100,true,false);
							if(getValueFrame() == 100){
								p.way = "Down";
								p.shootArrow(hud,4,-14);}
							break;
						case "Left":
							p.state = p.state.BowLeft;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							SET_FINISH_FRAME(100,true,false);
							if(getValueFrame() == 100){
								p.way = "Left";
							    p.shootArrow(hud,-16,4);}
							break;
						case "Right":
							p.state = p.state.BowRight;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							SET_FINISH_FRAME(100,true,false);
							if(getValueFrame() == 100){
								p.way = "Right";
							    p.shootArrow(hud,16,4);}
							break;
					}
					break;
				case "B":
					roll++;
					setRound++;
					if(Gdx.input.justTouched()&&roll == 1)
						game.manager.get("Sound/roll.wav", Sound.class).play();
					p.moveSpeed = 2;
					switch(dir){
						case "Up":
							p.state = p.state.RoamUp;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-20, 0, 0,oneTouched(setRound));
							SET_FINISH_FRAME(120,true,false);
							p.setUp();
							break;
				        case "Down":
							p.state = p.state.RoamDown;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-20, 0, 0,oneTouched(setRound));
							SET_FINISH_FRAME(120,true,false);
							p.setDown();
							break;
						case "Left":
							p.state = p.state.RoamLeft;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-20,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(160,true,false);
							p.setLeft();
							break;
						case "Right":
							p.state = p.state.RoamRight;
							p.stateEffect("Player/LinkAtlas.png",20,29);
							change(-20,0,0,oneTouched(setRound));
							SET_FINISH_FRAME(160,true,false);
							p.setRight();
							break;
						}
					break;
				case "HookShot":
						game.manager.get("Sound/hookshot_fire.wav", Music.class).play();
					switch(dir){
						case "Up":
							p.addHookShotV("peakUp",14,6,2);
							break;
						case "Down":
							p.addHookShotV("peakDown",-8,-6,0);
							break;
						case "Right":
							p.addHookShotH("peakRight",13,9,2);
							break;
						case "Left":
							p.addHookShotH("peakLeft",-13,-9,2);
							break;
					}
					break;
				case "isEmpty":
					p.moveSpeed = 1;
					p.takeHshot();
					setRound = shield = roll = 0;
					p.setSword = p.setShield = false;
					game.manager.get("Sound/hookshot_fire.wav", Music.class).stop();
			        if ((angleRad >= 45 && angleRad < 135)&&(!p.shockUp)){
						p.setBodyUp();
						p.resX = p.resY = 16;
						p.resPosY = p.rePosX = 0;
						p.setTexture("Player/LinkAtlas.png",20,29);
				        p.state = p.state.IdlingUp;
				        dir = "Up";
						point = 0;
				        p.setUp();
						p.resetIndex();
				        return;}
			   else if ((angleRad >= 135 && angleRad < 225)&&(!p.shockLeft)){
				        p.setBodyLeft();
				        p.resX = p.resY = 16;
				        p.resPosY = p.rePosX = 0;
				        p.setTexture("Player/LinkAtlas.png",20,29);
				        p.state = p.state.IdlingLeft;
				        dir = "Left";
				        point = 0;
				        p.setLeft();
				        p.resetIndex();
				        return;}
			   else if ((angleRad >= 225 && angleRad < 315)&&(!p.shockDown)){
				        p.setBodyDown();
				        p.resX = p.resY = 16;
				        p.resPosY = p.rePosX = 0;
				        p.setTexture("Player/LinkAtlas.png",20,29);
				        p.state = p.state.IdlingDown;
				        dir = "Down";
				        point = 0;
				        p.setDown();
				        p.resetIndex();
				        return;}
			   else if (((angleRad >= 315 && angleRad < 360)||(angleRad > 0 && angleRad < 45))&&(!p.shockRight)){
				        p.setBodyRight();
				        p.resX = p.resY = 16;
				        p.resPosY = p.rePosX = 0;
				        p.setTexture("Player/LinkAtlas.png",20,29);
				        p.state = p.state.IdlingRight;
				        dir = "Right";
				        point = 0;
				        p.setRight();
				        p.resetIndex();
				        return;}
			   else if(angleRad == 0 || p.shockUp || p.shockDown || p.shockLeft || p.shockRight){
				   p.resetIndex();
				   p.stateEffect("Player/LinkAtlas.png",20,29);
				        return;}
			       break;
			 }
			switch(dir){
				case "Up":
					p.state = p.state.IdlingUp;
					break;
				case "Down":
					p.state = p.state.IdlingDown;
					break;
				case "Left":
					p.state = p.state.IdlingLeft;
					break;
				case "Right":
					p.state = p.state.IdlingRight;
					break;
			}
			
		}

	public Stage getStage(){
		return stage;
	}
		
}
