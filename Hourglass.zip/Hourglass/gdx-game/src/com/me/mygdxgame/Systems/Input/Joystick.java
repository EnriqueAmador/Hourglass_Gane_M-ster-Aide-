/*******************************************************************************
 * @ (#) Joystick.java           
 *                                                 
 * 
 * Copyright (c) 2017/Diciembre - 2018 Rockbelle(Henriqu TA), Inc.
 * Juigalpa, Chontales, Nicaragua - Bo. Carlos Nuñez, NIC
 *
 * All rights reserved.
 * 
 * Este codigo esta bajo licencia de GNU, todo uso de este codigo esta libre
 * salvo a que no se haga con fines ajenos a la ley, tomando en cuenta, las normas
 * y leyes de cada estado, pais o region, no se debera usar este codigo, con fines
 * malvados, a menos de contar con la autorizacion de su creador.
 *
 * Este projecto esta desarollado con el Framework de LibGdx's Lib, a si mismo esta
 * sujeta a sus propias politicas y posibles recursos de terceros.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

package com.me.mygdxgame.Systems.Input;

import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Touchpad;
import com.badlogic.gdx.graphics.Texture;
import com.me.mygdxgame.*;
import com.badlogic.gdx.scenes.scene2d.*;

/**
 * Esta clace es la que representa al joystick de juego con el que se mueve el 
 * jugador sobre las coordenadas
 * 
 * @Desing: Esta clace fue desarrollada por el Author descrito más abajo
 * esta sujeta a Copyright (c), no obstante, su propósito es génerico, 
 * se prohíbe, la reproducción total y parcial del código, 
 * sin autorización de su dueño
 *
 * @Version           3.0 (1,20-04-2018)
 * @Author            Tomás E. Téllez A.
 */

public class Joystick extends Touchpad
{
	/** Utilizado para obtener zona en radios por donde se mueve la perilla*/
	public static float deadzoneRadius;
	
	/**
	* Contiene un super, al que se le pasan dos objetos para su debido trabajo
	* este super es trabajado por {@Touchpad de Libgdx}
	*
	* @param deadzoneRadius zona del knob
	* @param {Touchpad.getTouchPadStyle} instancia utilizada para devolver el estilo
	*/
	    public Joystick(Hourglass game){     
	      super(deadzoneRadius, Joystick.getTouchPadStyle(game));     
	      
		   }
		   
	/**
	* Métodos utilizado para devolver el estilo de los drawable que va a llevar(imágenes)
	*/
	private static TouchpadStyle getTouchPadStyle(Hourglass game){
	     Skin touchpadSkin1;
		 Skin touchpadSkin2;
		 TouchpadStyle touchpadStyle;
		 
	    touchpadSkin1 = new Skin(); 
        touchpadSkin2 = new Skin();    
	    touchpadSkin1.add("touchBackground",game.manager.get("GamePad/background.png",Texture.class));     
	    touchpadSkin2.add("touchKnob",game.manager.get("GamePad/knob.png",Texture.class));
		touchpadStyle = new TouchpadStyle();
		touchpadStyle.background = touchpadSkin1.getDrawable("touchBackground");     
		touchpadStyle.knob = touchpadSkin2.getDrawable("touchKnob");   
		touchpadStyle.knob.setBottomHeight(12);
		
		return touchpadStyle; 
		
	}

}
