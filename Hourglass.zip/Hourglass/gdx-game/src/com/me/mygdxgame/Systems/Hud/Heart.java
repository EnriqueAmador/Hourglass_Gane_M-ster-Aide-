package com.me.mygdxgame.Systems.Hud;

import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.*;

public class Heart extends Actor
{
	Animation left;
    public TextureRegion region;
    float time;
	
	public Heart(TextureRegion texture){
		
		TextureRegion[]move = new TextureRegion[3];
        move[0] = new Sprite(new Texture(Gdx.files.internal("Hud/Healt1.png")));
        move[1] = new Sprite(new Texture(Gdx.files.internal("Hud/Healt.png")));
		move[2] = new Sprite(new Texture(Gdx.files.internal("Hud/Healt3.png")));
		
        left = new Animation(0.16f, move);
		
	}

	public void go(){}
	
	@Override
	public void draw(Batch batch,float parentAlpha)
	{
		time += Gdx.graphics.getDeltaTime();
        region = left.getKeyFrame(time,true);
        batch.draw(region,getX(),getY());
	}

}
