package com.me.mygdxgame.Systems.Mixed;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.scenes.scene2d.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.utils.*;
import com.me.mygdxgame.*;

public class Mixed{

	public int x, y, value1, value2;
	protected TiledMapTileLayer layer;
	protected int tileSize;
	private Sprite dintelUp, dintelDown;

	public Mixed(TiledMap map) {
		super();
     
		layer = (TiledMapTileLayer) map.getLayers().get(0);
        dintelUp = new Sprite(new Texture(Gdx.files.internal("Map/Dintel_Up.png")));
		dintelDown = new Sprite(new Texture(Gdx.files.internal("Map/Dintel_Down.png")));
		tileSize = map.getProperties().get("tilewidth", Integer.class);
        
	}
	
	public void draw(Hourglass game) {
	
		game.getDrawer().begin();
		game.getDrawer().draw(dintelUp, 720, 160, 16, 16);
		game.getDrawer().draw(dintelDown, 720, 144, 16, 16);
		game.getDrawer().end();
	}

}
