package com.me.mygdxgame.Systems.Hud;

import com.me.mygdxgame.Hourglass;

import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import java.util.HashMap;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.scenes.scene2d.utils.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.scenes.scene2d.actions.*;

public class Hud
{
	private Image Bow, O_Clock, Key, bar;
	private SpriteBatch batch;
	private NinePatch magic_green,magicBackground;
	private final Texture piece_Heart;
	private final Texture magicBar;
	private final Texture magicGreen;
	private HashMap <Integer,Image> piece_Heart_Hud = new HashMap<Integer,Image>();
	public Table hud;
	public int lessMagic;// = 180;
	private Skin skin;
	private Label live, count, key, hourglass;
	private Stage stage;
	public int protectedHeart,/* = 10,*/ mins = 0,numA;
	public int mins_h,changeHeart = 64,lessHeart;// = 5;
	private Integer addKey/* = 0*/, secs = 0, value = 60;
	
	public Hud(Hourglass game,int lessMagic,int lessHeart,int protectedHeart,int addKey,int mins_h){
		this.lessMagic = lessMagic;
		this.lessHeart = lessHeart;
		this.addKey = addKey;
		this.mins_h = mins_h;
		this.protectedHeart = protectedHeart;
		skin = new Skin(Gdx.files.internal("Font/uiskin.json"));
		Bow = new Image(game.manager.get("Hud/arrow_icon.png",Texture.class));
		O_Clock = new Image(game.manager.get("Hud/O'clock.png", Texture.class));
		Key = new Image(game.manager.get("Hud/small_keys.png", Texture.class));
		this.magicBar = game.manager.get("Hud/magic_bar.png",Texture.class);
		this.magicGreen = game.manager.get("Hud/magic_bar.png",Texture.class);
		this.piece_Heart = game.manager.get("Hud/piece_of_heart_icon.png", Texture.class);
		batch = new SpriteBatch();
		
		live = new Label("---Life---", skin);
		live.setFontScale(2,1);
		count = new Label(String.format("X"+"%02d", protectedHeart), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		count.setFontScale(2,1);
		key = new Label(String.format("%02d", addKey),new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		key.setFontScale(2,1);
		hourglass = new Label(String.format("%02d:%02d:%02d", mins_h,mins,secs), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		hourglass.setFontScale(2,1);
		
		NinePatch magic_bar = new NinePatch(new TextureRegion(magicBar,0,5,16,43));
		magic_bar.setPadding(5000,5000,50,50);
		bar = new Image(magic_bar);
		
		magic_green = new NinePatch(new TextureRegion(magicGreen,16,5,15,43));
		magicBackground = new NinePatch(new TextureRegion(magicGreen,16,5,15,43));
		magicBackground.setColor(Color.BLACK);

		stage = new Stage();

		hud = new Table();
		hud.setFillParent(true);
        hud.top().left();
        //hud.debug();
        hud.add().size(1,1);
        hud.add().size(1,1);
        hud.add().size(1,1);
        hud.add().size(1,1);
        hud.add().size(1,1);
        hud.row();
        hud.add(live).colspan(5);
        hud.add().space(60);
        hud.add(Bow).size(50,50);
        hud.add().space(60);
        hud.add(Key).size(50,50);
        hud.add().space(60);
        hud.add(O_Clock).size(50,50);
        hud.row();
        for(int piece = 0;piece < 5;piece++){
			if(piece > lessHeart - 1) //&& piece < 5)
            piece_Heart_Hud.put(piece,lessHeart());
			else piece_Heart_Hud.put(piece,image());
            hud.add(piece_Heart_Hud.get(piece)).size(45,32).fill();}
        hud.add().space(60);
        hud.add(count);
        hud.add().space(60);
        hud.add(key);
        hud.add().space(60);
        hud.add(hourglass);
        hud.row();
        hud.add(bar).size(68,180).top();
		
		stage.addActor(hud);
		
	}
	
	public void signalTopArrow(){
		if(protectedHeart == 10)
			count.setColor(Color.YELLOW);
			else
				count.setColor(Color.WHITE);
	}
	
	public void addKey(){
		addKey++;
		key.setText(String.format("%02d",addKey));
	}
	
	public void addArrow(){
		protectedHeart++;
		count.setText(String.format("X"+"%02d",protectedHeart));
	}
	
	public void downArrow(){
		if(protectedHeart > 0){
			protectedHeart--;
			numA = protectedHeart + 1;}
			else{
				numA = protectedHeart - 1;}
		count.setText(String.format("X"+"%02d",protectedHeart));
	}
	
	public Image image(){
		return new Image(getPiece());
	}
	
	public Image lessHeart(){
		return new Image(getTakeHeart());
	}
	
	public TextureRegion getPiece(){
		return new TextureRegion(piece_Heart,changeHeart,0,16,16);
	}
	
	public TextureRegion getTakeHeart(){
		return new TextureRegion(piece_Heart,0,0,16,16);
	}
	
	public int getStateArrow(){
		return protectedHeart;
	}
	
	public int addHudKey(){
		return addKey;
	}
	
	public void lessHeart(int start){
		if((start == 1)&&(lessHeart > -1 && lessHeart < 6)){
			changeHeart = 0;lessHeart--;
			hud.getCell(piece_Heart_Hud.get(lessHeart)).setActor(new Image(getPiece()));
		}
	}
	
	public int getHeart(){
		return lessHeart;
	}
	
	public int getKeys(){
		return addKey;
	}
	
	/*public void lessHeart(){
		for(int i = 0;i < lessHeart;i++)
	       hud.getCell(piece_Heart_Hud.get(i)).
		   setActor(new Image(getTakeHeart()));
	}*/
	
	public void generateHud(){
		
		//TextureRegion change = new TextureRegion(piece_Heart,48,0,16,16);
		value++;
		mins = (int) value / 60;
        secs = (int) value - mins * 60;
		value = (mins > 59) ? 60 : value;
		if(mins > 59)mins_h++;
		
		hourglass.setText(String.format("%02d:%02d:%02d", mins_h,mins,secs));
		
		batch.begin();
		magicBackground.draw(batch,-5,(int)Gdx.graphics.getHeight() - 312,86,193);
		magic_green.draw(batch,-1,(int)Gdx.graphics.getHeight() - 308,75,lessMagic);
		batch.end();
		
		stage.draw();
		stage.act(Gdx.graphics.getDeltaTime());
		
	}
	
	public void dispose(){
		batch.dispose();
		piece_Heart.dispose();
		magicGreen.dispose();
		magicBar.dispose();
	}
	
}
