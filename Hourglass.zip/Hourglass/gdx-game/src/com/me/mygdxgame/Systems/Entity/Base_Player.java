/*******************************************************************************
 * @ (#) Base_Player.java 
 * 
 * Copyright (c) 2017/Diciembre - 2018 Rockbelle(Henriqu TA), Inc.
 * Juigalpa, Chontales, Nicaragua - Bo. Carlos Nuñez, NIC
 *
 * All rights reserved.
 * 
 * Este codigo esta bajo licencia de GNU, todo uso de este codigo esta libre
 * salvo a que no se haga con fines ajenos a la ley, tomando en cuenta, las normas
 * y leyes de cada estado, pais o region, no se debera usar este codigo, con fines
 * malvados, a menos de contar con la autorizacion de su creador.
 *
 * Este projecto esta desarollado con el Framework de LibGdx's Lib, a si mismo esta
 * sujeta a sus propias politicas y posibles recursos de terceros.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

package com.me.mygdxgame.Systems.Entity;

import org.enriqu.ta.SYSTEMS.Animation.AnimationSystem;
import org.enriqu.ta.SYSTEMS.Input.Event;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.*;

/**
* Esta clace representa y genera al jugador, carga sus texturas, asi como las 
* estaticas y las dinamicas.
*
* @Version           0.1 (1,20-04-2018)
* @Author            Tomàs E. Téllez A.
*/

public class Base_Player extends AnimationSystem {

/** Se heredo de AnimationSystems para crear las animacion que debian calcular sus
frames con exactitud*/

/** Objeto entero creado para administrar que velocidad debe llevar el jugador*/
	public int moveSpeed;
	
/** Objeto entero creado para dar posicion en las coordenadas iniciales y pos, al jugador*/
	public int x, y;
	public int pixX;// = 43;
	public float camX;// = pixX + 305;
	public int pixY;// = 96;
	public float camY;// = pixY;
	public boolean shockUp,shockDown,shockLeft,shockRight;
	protected String statePlayer;
	
/** Objeto entero creado para administrar calcular la posicion de desplace del jugador*/
	protected int xdest, ydest;
	
/** Objeto entero creado para administrar posibles colisiones con muros en el eje Y*/
	protected int rowtile;
	
/** Objeto entero creado para administrar posibles colisiones con muros en el eje X*/
	protected int coltile;
	
/** Objeto boolean creado para obtener si se mueve el juagdor*/
	public boolean moving;

/** Objeto boolean creado para dar movilidad hacia abajo*/
	protected boolean down; 
	
/** Objeto boolean creado para dar movilidad hacia arriba*/
	protected boolean up;
	
/** Objeto boolean creado para dar movilidad hacia izquierda*/
	protected boolean left;
	
/** Objeto boolean creado para dar movilidad hacia la derecha*/
	protected boolean right;
	
/** Objeto flotante creado para calcular el tiempo delta de cada frame*/
	protected float time;
	
/** Objeto TiledMap capas, creado para obtener las caracteristicas del mundo*/
	protected TiledMapTileLayer layer;
	
/** Objeto entero creado para conocer el ancho de los tile*/
	protected int tileSize;
	
/**
* El constructor de Base_Player, esta creado para dibujar en el mapa en esta caso
* en un mapa de tile, al jugador mediante enteros escritos.
*
* @param map, es donde se localizara el jugador.
* @param setX, entero para posicion en la coordenada X.
* @param setY, entero para posicion en la coordenada Y.
*/
	public Base_Player(TiledMap map,int setX, int setY) {
		super();
// En el constructor se inicializan los objetos creandolos como nuevos y la posicion
	
		tileSize = map.getProperties().get("tilewidth", Integer.class);
		layer = (TiledMapTileLayer) map.getLayers().get(0);

		x = setX * tileSize;
		y = setY * tileSize;
		xdest = x;
		ydest = y;
	}

/**
* Este metodo es usado como puerta para dar la movilida del jugador hacia arriba
* al mismo tiempo emplea metodos que constribuyen para que el metodo funcion.
*/
	public void setUp() {
//Se retorna mediante moving, up y los objetos booleano el estado en Y+.
		//writeData();
		if (moving)
			return;
		up = true;
		statePlayer = "Up";
		moving = getCollisionTile();
	}

/**
* Este metodo es usado como puerta para dar la movilida del jugador hacia abajo
* al mismo tiempo emplea metodos que constribuyen para que el metodo funcion.
*/
	public void setDown() {
//Se retorna mediante moving, Down y los objetos booleano el estado en Y-.
		//writeData();
		if (moving)
			return;
		down = true;
		statePlayer = "Down";
		moving = getCollisionTile();
	}

/**
* Este metodo es usado como puerta para dar la movilida del jugador hacia la izquierda
* al mismo tiempo emplea metodos que constribuyen para que el metodo funcion.
*/
	public void setLeft() {
//Se retorna mediante moving, Left y los objetos booleano el estado en X-.
		//writeData();
		if (moving)
			return;
		left = true;
		statePlayer = "Left";
		moving = getCollisionTile();
	}

/**
* Este metodo es usado como puerta para dar la movilida del jugador hacia la derecha
* al mismo tiempo emplea metodos que constribuyen para que el metodo funcion.
*/
	public void setRight() {
// Se retorna mediante moving, Right y los objetos booleano el estado en X-.
	    //writeData();
		if (moving)
			return;
		right = true;
		statePlayer = "Right";
		moving = getCollisionTile();
	}

	public void writeData(){
		
	}
	
/** Utilizado para retornar true o false si el jugador colisiona con un tile
en una celda de blocked*/
	public boolean getCollisionTile() {
// Trabaja mediante  los eventos ocorridos en el que puden afectar a up,down,right o left.

		rowtile = y / tileSize;
		coltile = x / tileSize;
		
		if (up) {
			if (layer.getCell(coltile, rowtile + 1).getTile().getProperties()
					.containsKey("blocked")) {
					shockUp = true;
				return false;
			} else {
				shockDown = false;
				shockLeft = false;
				shockRight = false;
				ydest = y + tileSize;
				pixY = pixY - 1;
				camY += 5.1;
			}
		}
		if (down) {
			if (layer.getCell(coltile, rowtile - 1).getTile().getProperties()
					.containsKey("blocked")) {
					shockDown = true;
				return false;
			} else {
				shockUp = false;
				shockRight = false;
				shockLeft = false;
				ydest = y - tileSize;
				pixY = pixY + 1;
				camY -= 5.1;
			}
		}
		if (left) {
			if (layer.getCell(coltile - 1, rowtile).getTile().getProperties()
					.containsKey("blocked")) {
					shockLeft = true;
				return false;
			} else {
				shockDown = false;
				shockUp = false;
				shockRight = false;
				xdest = x - tileSize;
				pixX -= 1;
				camX -= 5.1;
			}
		}
		if (right) {
			if (layer.getCell(coltile + 1, rowtile).getTile().getProperties()
					.containsKey("blocked")) {
					shockRight = true;
				return false;
			} else {
				shockUp = false;
				shockDown = false;
				shockLeft = false;
				xdest = x + tileSize;
				pixX += 1;
				camX += 5.1;
			}
		}
		return true;
	}

/** Utilizado para darle movilidad por ambos ejes al jugador*/
	public void getUpdatePosition() {
// Utilizado como proveedor de velocidad para el jugador.
		
		if (left && x > xdest) {
			drawFrame(0,280,5,180,true,false,false);
			x -= moveSpeed;
		} else {
			left = false;
		}
		if (left && x < xdest) {
			x = xdest;
		}
		if (right && x < xdest || right) {
			drawFrame(0,280,5,180,true,true,false);
			x += moveSpeed;
		} else {
			right = false;
		}
		if (right && x > xdest) {
			x = xdest;
		}
		if (up && y < ydest) {
			drawFrame(0,0,5,180,true,false,false);
			y += moveSpeed;
		} else {
			up = false;
		}
		if (up && y > ydest) {
			y = ydest;
		}
		if (down && y > ydest) {
			drawFrame(0,139,5,180,true,false,false);
			y -= moveSpeed;
		} else {
			down = false;
		}
		if (down && y < ydest) {
			y = ydest;
		}
	}
	
}
