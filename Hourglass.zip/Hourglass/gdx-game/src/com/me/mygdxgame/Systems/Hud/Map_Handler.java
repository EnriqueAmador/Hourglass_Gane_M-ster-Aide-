package com.me.mygdxgame.Systems.Hud;

import com.me.mygdxgame.Hourglass;
import com.me.mygdxgame.Actors.Heroe;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Pixmap.Format;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.graphics.g2d.*;

public class Map_Handler
{
	private Pixmap pmap;
	private Texture map,pixPlayer;
	private OrthographicCamera camera;
	public MiniMapViewport mapViweport;

    public Map_Handler(Heroe player){
		mapViweport = new MiniMapViewport(150,150);
		map = new Texture(Gdx.files.internal("Map/minimap.png"));
		pmap = new Pixmap(100,100,Format.RGBA8888);
		pixPlayer = new Texture(createPlayer(player));
		camera = new OrthographicCamera();
		camera.setToOrtho(false,300,200);
		camera.zoom = 1f;
    }

    public void mini_map(Heroe player,Hourglass game){
		mapViweport.apply();
		pixPlayer.draw(createPlayer(player),0,0);
		camera.position.set(player.camX,player.camY,0);
		camera.update();
		game.getDrawer().setProjectionMatrix(camera.combined);
		game.getDrawer().begin();
		game.getDrawer().draw(map,25,0,700,650);
		game.getDrawer().draw(pixPlayer,25,0,700,650);
		game.getDrawer().end();
    }
	
	private Pixmap createPlayer(Heroe player){
		pmap.setColor(Color.rgba8888(0f,0f,0f,0f));
		pmap.fill();
		pmap.setColor(Color.RED);
		pmap.drawPixel(43,99);
		pmap.setColor(Color.YELLOW);
		pmap.drawPixel(player.pixX,player.pixY);
		
		return pmap;
	}
	
	public void clearPixmap(){
		pmap.dispose();
		pixPlayer.dispose();
	}
	
	public void resize(){
		mapViweport.screenUpdate();
	}
	
	public int getPixX(Heroe player){
		return player.pixX;
	}
	
	public int getPixY(Heroe player){
		return player.pixY;
	}
	
	public float getCamX(Heroe player){
		return player.camX;
	}
	
	public float getCamY(Heroe player){
		return player.camY;
	}
}

class MiniMapViewport extends com.badlogic.gdx.utils.viewport.FitViewport
{
	int sWidth;
	int sHeight;

	public MiniMapViewport(int sWidth,int sHeight){
		super(sWidth,sHeight);
		this.sWidth = sWidth;
		this.sHeight = sHeight;
	}

	public void screenUpdate(){
		update(sWidth,sHeight);
		setScreenPosition(Gdx.graphics.getWidth() - 350,5);
	}
}

