package com.me.mygdxgame.Systems.Entity;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.math.*;
import com.me.mygdxgame.*;
import com.me.mygdxgame.Actors.*;
import com.me.mygdxgame.Systems.Hud.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.badlogic.gdx.audio.*;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.actions.*;
import com.me.mygdxgame.Screen.*;

public class EnemySystem extends com.me.mygdxgame.Systems.Entity.Base_Enemies
{
	public boolean death;
	protected boolean detected = true, stopLapse = true;
	protected String getBossWalking, pro;

	public enum State{
        WALKING_UP,
        WALKING_DOWN,
        WALKING_LEFT,
        WALKING_RIGHT,
		ATTACKING_UP,
		ATTACKING_DOWN,
		ATTACKING_LEFT,
		ATTACKING_RIGHT;

        private static State getRandomWalkingEnemies() {
            return values()[(int)(MathUtils.random()*8)];
        }

	}

	protected int duration, target, pr = 0, count = 0, xf;
	protected Animation
	dieState,
	StateAnimation,
	WALKING_RIGHT,
	WALKING_LEFT,
	WALKING_UP,
	WALKING_DOWN;
	protected Animation pieceLife;
	protected State state_Direction;
	protected String enemies_State = "";
	protected Sprite stop_left;
	protected boolean bodyItemDetected;
	protected Animation_Graphics sprite;
	protected int changeState;
	protected int scrX,scrY;
	private boolean setActiveItem;
	private boolean shock;
	private float time;
	private int timerCollision = 2;
	private int takeHeart;
	private int tint;
	private int timeShowLife;
	private int quarterLife = 64;
	private int i,j;
	private int millisPlay;
	private TextureRegion current;
	private TextureRegion[]die;
	private Animation dieFinal;
	private Texture keyWinner;
	private Texture arrowMod;
	private Rectangle bodyDef;
	private Array<Rectangle> bodyItems;
	private String iD;
	private GameScreen screen;
	//public Preferences prefEnemy;

	public EnemySystem(GameScreen screen,TiledMap map,String iD,boolean setActiveItem,int i1,int i2){
		super(screen,map,iD,setActiveItem,i1,i2);
		this.setActiveItem = setActiveItem;
		this.iD = iD;
		this.screen = screen;
		sprite = new Animation_Graphics(Hourglass.manager.get("Enemies/enemies_atlas.png",Texture.class));
		bodyDef = new Rectangle((int)getX(),(int)getY(),16,16);
		die = sprite.animFinal("Enemies/enemy_die.png",3,1);
		dieFinal = new Animation(0.19f,die);
		keyWinner = Hourglass.manager.get("Hud/small_keys.png",Texture.class);
		arrowMod = Hourglass.manager.get("Hud/item_arrow.png", Texture.class);
		//prefEnemy = Gdx.app.getPreferences(iD);
		death = screen.pref.getBoolean(iD,false);
		
		if(setActiveItem)
		bodyItems = new Array<Rectangle>();
	}
	
	@Override
	public void update(float dt)
	{
		time += Gdx.graphics.getDeltaTime();
		
		if((changeState == 30)){
			millisPlay++;
			j = i = 7;
			if(!death)
			current.setRegion(keyWinner);
			else current.setRegion(arrowMod);
			if(millisPlay == 1){
				Hourglass.manager.get("Sound/secret.ogg", Music.class).play();
				millisPlay = 2;
			return;}
			return;
		}
		
		if((quarterLife == -16)){
			changeState++;
			current = getDieAnim().getKeyFrame(time,true);
			}else{
				current = ENEMIES_BIT().getKeyFrame(time,true);
				j = scrY; i = scrX;
				changeState = 0;
				getNextPostion();
				}

		if (x == xdest && y == ydest){
			right = false;
			up = false;
			down = false;
			left = false;
			moving = false;
		}

	}

	public Animation getDieAnim(){
		return dieState = dieFinal;
	}
	
	public Animation ENEMIES_BIT(){
		switch (enemies_State){
			case "Right": 
				StateAnimation = WALKING_RIGHT;
				break;
			case "Left": 
				StateAnimation = WALKING_LEFT;
				break;
			case "Up": 
				StateAnimation = WALKING_UP;
				break;
			default : 
				StateAnimation = WALKING_DOWN;
		}
		return StateAnimation;
	}

	private TextureRegion getLifeIcon(Hourglass game){
		return new TextureRegion(game.manager.get("Hud/piece_of_heart_icon.png", Texture.class)
		,quarterLife,0,16,16);
	}
	
	private void collision (Heroe player,Hud hud){
		if(getOverlaps(player,hud)&&(getTimeCollision()&&!getProct(player))){
			takeHeart++;
			hud.lessHeart(takeHeart);
			timerCollision++;
			player.minPosition();
			}
		if(!getOverlaps(player,hud)){
			timerCollision = 2;takeHeart = 0;
			}
		if(getOverlapArrow(player)
			||getOverlapHShot(player)
			||getOverlapSword(player)){
				shock = true;
			}
		timeShowLife += (shock)?1:0;
	}
	
	public void updateCollision(Heroe player,Hud hud){
		collision(player,hud);
		
	}
	
	public void clearData(Hud hud){
		if(hud.getHeart() < 2)
		screen.pref.clear();
	}
	
	public boolean getTimeCollision(){
		return timerCollision > 0 && timerCollision < 5?true:false;
		}
	
	protected boolean getOverlaps(Heroe player,Hud hud){
		if((hud.getHeart() < 1)){
			screen.pref.putBoolean(iD,false);
			screen.pref.flush();
			return true;}
		   else
		if(bodyDefEnemy().overlaps(player.bodyDefPlayer())
			&&(hud.getHeart() > 0 && changeState == 30)){
			 screen.pref.putBoolean(iD,true);
			 screen.pref.flush();}
			
		if((bodyDefEnemy().overlaps(player.bodyDefPlayer()))){
			if((changeState != 30))
				player.RED();
				tint++;
			return true;
		}
		if((bodyItemDetected)&&(!getProct(player))){
			player.RED();
			tint++;
			return true;
			}
		if(tint > 8){
			player.WHITE();
			tint = 0;
		    return false;}
		return false;
	}
	
	public boolean getOverlapSword(Heroe player){
		return bodyDefEnemy().overlaps(player.bodySword())&&player.setSword?true:false;
	}
	
	public boolean getOverlapArrow(Heroe player){
		return bodyDefEnemy().overlaps(player.reBodyDefArrow())?true:false;
	}
	
	public boolean getOverlapHShot(Heroe player){
		return bodyDefEnemy().overlaps(player.bodyPickHShot())?true:false;
	}
	
	public boolean getStateKey(Heroe player,Hud hud){
		return getOverlaps(player,hud)&& changeState == 30?true:false;
	}
	
	public boolean getProct(Heroe player){
		return bodyDefEnemy().overlaps(player.bodyShield())&&player.setShield?true:false;
	}
	
	protected void updateFrame(int local, int pass, final int stop,Hourglass game,Heroe player,Hud hud){

		if (x == ToVectorX && y == ToVectorY && stopLapse){
			getBossWalking = state_Direction.getRandomWalkingEnemies().toString();
			pr++;
			target = MathUtils.random(local, pass);
		}
		else{count++;}

		bodyDef.x = (int)getX();
		bodyDef.y = (int)getY();
	
		//renderElement(game,player);
		
		shield = getProct(player);
	
		switch (getBossWalking){
			case "WALKING_RIGHT":
				if (pr == 1){
					ToVectorX = x + (16 * target);
					pr = 0;}
				enemies_State = "Right";
				setRight();
				break;
			case "WALKING_LEFT":
				if (pr == 1)
				{ToVectorX = x - (16 * target);
					pr = 0;}
				enemies_State = "Left";
				setLeft();
				break;
			case "WALKING_UP":
				if (pr == 1)
				{ToVectorY = y + (16 * target);
					pr = 0;}
				enemies_State = "Up";
				setUp();
				break;
		    case "WALKING_DOWN":
				if (pr == 1)
				{ToVectorY = y - (16 * target);
					pr = 0;}
				enemies_State = "Down";
				setDown();
				break;
			default:
				pr = 0;
				addElement(game);
				if (count < stop){
					stopLapse = false;
					stop();
				}
				else{
					stopLapse = true;count = 0;
				}
				break;

		}
		if (moving == false)
		{ToVectorX = x;ToVectorY = y;}
		
	}

	protected void renderElement(Hourglass game,Heroe player){
		
	}
	
	protected void addElement(Hourglass game){
		
	}
	
	public Rectangle bodyDefEnemy(){
		return bodyDef;
	}
	
	public Array<Rectangle> bodyDefItem(){
		return bodyItems;
	}
	
	private boolean killed(Heroe player,Hud hud){
		return getOverlapArrow(player)&&hud.lessMagic != 0?true:false;
	}
	
	public String getArray(){
		return bodyDefItem().toString();
	}
	
	public float getX(){
		return x;
	}
	
	public float getY(){
		return y;
	}
	
	@Override
	public void draw(Hourglass game,Heroe player,Hud hud,SpriteBatch sb)
	{
		renderElement(game,player);
		
		sb.begin();
		sb.draw(current,x,y,i,j);
		if(killed(player,hud)&&hud.lessMagic != 0)
			quarterLife = -16;
		if((timeShowLife > 1 && timeShowLife < 38)){
			sb.draw(getLifeIcon(game),x+4,y+18,8,8);
			}
		else if(timeShowLife == 38){
			timeShowLife = 0;
			quarterLife = quarterLife - 16;
			shock = false;
			}
		sb.end();
	}
}
