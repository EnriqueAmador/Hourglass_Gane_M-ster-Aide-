/*******************************************************************************
 * @ (#) OrthoCamera.java 
 * 
 * Copyright (c) 2017/Diciembre - 2018 Rockbelle(Henriqu TA), Inc.
 * Juigalpa, Chontales, Nicaragua - Bo. Carlos Nuñez, NIC
 *
 * All rights reserved.
 * 
 * Este codigo esta bajo licencia de GNU, todo uso de este codigo esta libre
 * salvo a que no se haga con fines ajenos a la ley, tomando en cuenta, las normas
 * y leyes de cada estado, pais o region, no se debera usar este codigo, con fines
 * malvados, a menos de contar con la autorizacion de su creador.
 *
 * Este projecto esta desarollado con el Framework de LibGdx's Lib, a si mismo esta
 * sujeta a sus propias politicas y posibles recursos de terceros.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

package com.me.mygdxgame.Systems.Camera;

import com.me.mygdxgame.Actors.Heroe;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.maps.tiled.TiledMap;

/**
 * Esta clace es utilizada para mantener visible la posición actual
 * del jugador, utiliza sus ejes para ubicarse
 *
 * @ver Heroe.class
 * @ver {TiledMap.class} LibGdx
 
 * @Version           0.1 (1,20-04-2018)
 * @Author            Tomàs E. Téllez A.
 */
public class OrthoCamera
{
	/** Objeto de la camara ortografica utilizada para renderizar*/
	private OrthographicCamera camera;
	
	/** Objeto {@Heroe player}
	* utilizado para acceder a sus ejes de posición
	*/
	private Heroe player;
	
	/** Objetos enteros utilizado para registrar el ancho y alto del tile*/
	private int tilemapwidth, tilemapHeight;

	/**
	* Utilizado para poder pasarle parametros que construyan los valores
	* necesarios para que la camara trabaje
	*
	* @param map, ocupado para que la camara sepa que es aqui donde va a trabajar
	* @param Heroe, utilizado para que la camara obtenga lo que va enfocar en
	* en el Map
	*/
	public OrthoCamera(TiledMap map,com.me.mygdxgame.Actors.Heroe player)
	{ 
	  // Genera, inicializa los valores que van a hacer ocupados.
	  
		this.player = player;
		camera = new OrthographicCamera();
		camera.setToOrtho(false,190,95);
		camera.zoom = 1;
		camera.position.x = player.getX() + 190 / 4;
		camera.position.y = player.getY() + 95 / 4;
		tilemapwidth = map.getProperties().get("width", Integer.class);
		tilemapHeight = map.getProperties().get("height", Integer.class);
	}
	
	/**
	* Retorna el valor que tiene hasta el momento la camara
	* @ver GameScreen.class
	*/
	public OrthographicCamera getOrthocam()
	{
		camera.position.set(player.getX() + 190 / 4,player.getY() + 95 / 4,0);
        if (camera.position.x < camera.viewportWidth / 2)
		{
            camera.position.x = camera.viewportWidth / 2;}
        if (camera.position.x > tilemapwidth * 16 - camera.viewportWidth / 2)
		{
            camera.position.x = tilemapwidth * 16 - camera.viewportWidth / 2;}
        if (camera.position.y < camera.viewportHeight / 2)
		{
            camera.position.y = camera.viewportHeight / 2;}
        if (camera.position.y > tilemapHeight * 16 - camera.viewportHeight / 2)
		{
            camera.position.y = tilemapHeight * 16 - camera.viewportHeight / 2;}
		
		return camera;
	}
}
