package com.me.mygdxgame.Systems.Entity;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.scenes.scene2d.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.utils.*;
import com.me.mygdxgame.*;
import com.me.mygdxgame.Systems.Hud.*;
import com.me.mygdxgame.Actors.*;
import com.me.mygdxgame.Screen.*;

public class Base_Enemies{
	
	public int x, y, value1, value2, ToVectorX, ToVectorY;
	public int xdest, ydest;
	protected int rowtile;
	protected int coltile;
	protected boolean moving,shield;
	protected boolean up, moveDetection = false, Shield, Bow;
	protected boolean down, pastUp, pastLeft, pastRight;
	protected boolean left;
	protected boolean right, stop_player, s_l, s_r, s_d, s_u, arrow, shoot;
	protected int moveSpeed;
	protected TiledMapTileLayer layer;
	protected int tileSize;

	public Base_Enemies(GameScreen screen,TiledMap map,String iD,boolean item,int i1,int i2) {
		super();

        this.value1 = i1;
        this.value2 = i2;
		
		layer = (TiledMapTileLayer) map.getLayers().get(0);
        
		tileSize = map.getProperties().get("tilewidth", Integer.class);
        x = value1 * tileSize;
		y = value2 * tileSize;
		xdest = x;
		ydest = y;
		ToVectorX = x;
		ToVectorY = y;
	}

	public void PositionInitial() {
 
		
	}

	public void setUp() {
		if (moving)
			return;
		up = true;
		s_u = true; s_d = false; s_r = false; s_l = false;
		stop_player = false;
		moving = validateNextPostion();
	}

	public void setDown() {
		if (moving)
			return;
		down = true;
		s_d = true; s_r = false; s_l = false; s_u = false;
		stop_player = false;
		moving = validateNextPostion();
	}

	public void setLeft() {
		if (moving)
			return;
		left = true;
		s_l = true; s_r = false; s_d = false; s_u = false;
        stop_player = false;
		moving = validateNextPostion();
	}

	public void setRight() {
		if (moving)
			return;
		right = true;
		s_r = true; s_l = false; s_d = false; s_u = false;
        stop_player = false;
		moving = validateNextPostion();
	}

	public void stop(){
		stop_player = true;
	}
	
	public boolean validateNextPostion() {
		rowtile = y / tileSize;
		coltile = x / tileSize;
		if (up) {
			if (layer.getCell(coltile, rowtile + 1).getTile().getProperties()
				.containsKey("blocked")||layer.getCell(coltile, rowtile + 1).getTile().getProperties()
				.containsKey("Walls")||shield) {
						stop_player = true;
						pastUp = true;
				pastLeft = false;
				pastRight = false;
				return false;
			} else {
				stop_player = false;
				pastUp = false;
				pastLeft = false;
				pastRight = false;
				ydest = y + tileSize;
			}
		}
		if (down) {
			if (layer.getCell(coltile, rowtile - 1).getTile().getProperties()
				.containsKey("blocked")||layer.getCell(coltile, rowtile - 1).getTile().getProperties()
				.containsKey("Walls")||shield) {
					stop_player = true;
				pastUp = false;
				pastLeft = false;
				pastRight = false;
				return false;
			} else {
				stop_player = false;
				pastUp = false;
				pastLeft = false;
				pastRight = false;
				ydest = y - tileSize;
			}
		}
		if (left) {
			if (layer.getCell(coltile - 1, rowtile).getTile().getProperties()
				.containsKey("blocked")||layer.getCell(coltile - 1, rowtile).getTile().getProperties()
				.containsKey("Walls")||shield) {
					stop_player = true;
					pastLeft = true;
				pastUp = false;
				pastRight = false;
				return false;
			} else {
				stop_player = false;
				pastLeft = false;
				pastUp = false;
				pastRight = false;
				xdest = x - tileSize;
			}
		}
		if (right) {
			if (layer.getCell(coltile + 1, rowtile).getTile().getProperties()
				.containsKey("blocked")||layer.getCell(coltile + 1, rowtile).getTile().getProperties()
				.containsKey("Walls")||shield) {
					stop_player = true;
				pastUp = false;
				pastLeft = false;
				pastRight = true;
				return false;
			} else {
				stop_player = false;
				pastUp = false;
				pastLeft = false;
				pastRight = false;
				xdest = x + tileSize;
			}
		}
		return true;
	}

	public void getNextPostion() {
       
        //if(moveDetection == false){
        //PositionInitial();}
        
		if (left && x > xdest) {
			x -= moveSpeed;
		} else {
			left = false;
		}
		if (left && x < xdest) {
			x = xdest;
		}
		if (right && x < xdest) {
			x += moveSpeed;
		} else {
			right = false;
		}
		if (right && x > xdest) {
			x = xdest;
		}
		if (up && y < ydest) {
			y += moveSpeed;
		} else {
			up = false;
		}
		if (up && y > ydest) {
			y = ydest;
		}
		if (down && y > ydest) {
			y -= moveSpeed;
		} else {
			down = false;
		}
		if (down && y < ydest) {
			y = ydest;
		}
  
	}
    
    //Metodo de actualizacion de movimientos del jugador

	public void update(float dt) {
		 
	}

	public void draw(Hourglass game,Heroe player,Hud hud,SpriteBatch sb) {

	}

}
