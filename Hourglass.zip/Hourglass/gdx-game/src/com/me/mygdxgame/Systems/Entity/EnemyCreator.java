package com.me.mygdxgame.Systems.Entity;

import com.me.mygdxgame.Actors.Enemies.Lynel;
import com.me.mygdxgame.Actors.Enemies.Gibdo;
import com.me.mygdxgame.Actors.Enemies.Tarosu;
import com.me.mygdxgame.Actors.Enemies.*;

import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.maps.*;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.*;
import com.me.mygdxgame.*;
import com.me.mygdxgame.Actors.*;
import com.badlogic.gdx.utils.*;
import com.me.mygdxgame.Systems.Hud.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.*;
import com.me.mygdxgame.Screen.*;
import java.util.*;
import java.util.HashMap;

public class EnemyCreator
{
	private Array<Lynel> lynel;
	private Array<Gibdo> gibdo;
	private Array<Tarosu> tarosu;
	private Array<Stalfos> stalfos;
	private Array<Arqueros> arqueros;
	private Array<Moblin> moblin;
	private Integer tarosuID = -1;
	private Integer lynelID = 10;
	private Integer stalfosID = 14;
	private Integer arquerosID = 17;
	private Integer gibdoID = 18;
	private Integer moblinID = 23;
	public boolean x,tarosud;
	private GameScreen screen;
	
	public EnemyCreator(GameScreen screen,TiledMap map){
		this.screen = screen;
		//screen.pref.put(mapRemove);
		//Se generan los enemigos del patron de lynel

	    lynel = new Array<Lynel>();
		
        for (MapObject object : map.getLayers().get(6).getObjects().getByType(RectangleMapObject.class))
		{
			lynelID++;
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
		    int x = (int)rect.x;
			int y = (int)rect.getY() / 16;
            lynel.add(new Lynel(screen,map,lynelID.toString(),true,x/16,y));
        }

		//Se generan los enemigos del patron del gibdo

		gibdo = new Array<Gibdo>();

        for (MapObject object : map.getLayers().get(3).getObjects().getByType(RectangleMapObject.class))
		{
			gibdoID++;
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
		    int x = (int) rect.x;
			int y = (int)rect.getY() / 16;
            gibdo.add(new Gibdo(screen,map,gibdoID.toString(),false,x/16,y));
        }

		//Se generan los enemigos del patron del tarosu

		tarosu = new Array<Tarosu>();

        for (MapObject object : map.getLayers().get(2).getObjects().getByType(RectangleMapObject.class))
		{
			tarosuID++;
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
		    int x = (int) rect.x;
			int y = (int)rect.getY() / 16;
            tarosu.add(new Tarosu(screen,map,tarosuID.toString(),false,x/16,y));
        }

		//Se generan los enemigos del patron del stalfos

		stalfos = new Array<Stalfos>();

        for (MapObject object : map.getLayers().get(7).getObjects().getByType(RectangleMapObject.class))
		{
			stalfosID++;
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
		    int x = (int) rect.x;
			int y = (int)rect.getY() / 16;
            stalfos.add(new Stalfos(screen,map,stalfosID.toString(),false,x/16,y));
        }

		//Se generan los enemigos del patron del arqueros

		arqueros = new Array<Arqueros>();

        for (MapObject object : map.getLayers().get(8).getObjects().getByType(RectangleMapObject.class))
		{
			arquerosID++;
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
		    int x = (int) rect.x;
			int y = (int)rect.getY() / 16;
            arqueros.add(new Arqueros(screen,map,arquerosID.toString(),true,x/16,y));
        }

		//Se generan los enemigos del patron del moblin

		moblin = new Array<Moblin>();

        for (MapObject object : map.getLayers().get(4).getObjects().getByType(RectangleMapObject.class))
		{
			moblinID++;
            Rectangle rect = ((RectangleMapObject) object).getRectangle();
		    int x = (int) rect.x;
			int y = (int)rect.getY() / 16;
            moblin.add(new Moblin(screen,map,moblinID.toString(),false,x/16,y));
        }
	}
	
	public void setEnemies(Hourglass game,Heroe player,Hud hud,float delta){
		
		for (Stalfos entity : stalfos){
			if(entity.getStateKey(player,hud)){
				stalfos.removeValue(entity,true);
				if(!entity.death)
					hud.addKey();
				else hud.addArrow();
				}else{
			entity.update(delta);
			entity.updateFrame(4,7,50,game,player,hud);
			entity.updateCollision(player,hud);
			entity.draw(game,player,hud,game.getDrawer());}
			}
		
	    for (Arqueros entity : arqueros){
		    if(entity.getStateKey(player,hud)){
				arqueros.removeValue(entity,true);
				if(!entity.death)
					hud.addKey();
				else hud.addArrow();
				}else{
			entity.update(delta);
			entity.updateFrame(3,8,50,game,player,hud);
			entity.updateCollision(player,hud);
			entity.draw(game,player,hud,game.getDrawer());}
			}
		
		for (Lynel entity : lynel){
			if(entity.getStateKey(player,hud)){
				lynel.removeValue(entity,true);
				if(!entity.death)
					hud.addKey();
				else hud.addArrow();
				}
			else{
				entity.update(delta);
			entity.updateFrame(1,6,50,game,player,hud);
			entity.updateCollision(player,hud);
			entity.draw(game,player,hud,game.getDrawer());}
			}
		
		for (Gibdo entity : gibdo){
			if(entity.getStateKey(player,hud)){
				gibdo.removeValue(entity,true);
				if(!entity.death)
					hud.addKey();
				else hud.addArrow();
				}
			else{
				entity.update(delta);
			entity.updateFrame(2,10,50,game,player,hud);
			entity.updateCollision(player,hud);
			entity.draw(game,player,hud,game.getDrawer());}
			}
			
		for (Moblin entity : moblin){
			if(entity.getStateKey(player,hud)){
				moblin.removeValue(entity,true);
				if(!entity.death)
					hud.addKey();
				else hud.addArrow();
				}
			else{
				entity.update(delta);
			entity.updateFrame(1,12,50,game,player,hud);
			entity.updateCollision(player,hud);
			entity.draw(game,player,hud,game.getDrawer());}
			}
			
		for (Tarosu entity : tarosu){
			if(entity.getStateKey(player,hud)){
				tarosu.removeValue(entity,true);
				if(!entity.death)
				hud.addKey();
				else hud.addArrow();
			}else{
			entity.update(delta);
			entity.updateFrame(3,5,110,game,player,hud);
			entity.updateCollision(player,hud);
			entity.draw(game,player,hud,game.getDrawer());}
			}
			
		x = tarosu.get(0).death;
	}
	
}
