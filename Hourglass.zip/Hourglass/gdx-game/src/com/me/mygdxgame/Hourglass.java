package com.me.mygdxgame;

import com.me.mygdxgame.Screen.GameScreen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.audio.*;
import com.me.mygdxgame.Screen.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.utils.viewport.*;

public class Hourglass extends Game {
	
	public static AssetManager manager;
	public String file;
	public String deleteFiles;
	private SpriteBatch batch;
	private FitViewport viewport;
	
	public final int V_WIDTH = 7;
    public final int V_HEIGHT = 6;
    public final float PPM = 100;
	
	@Override
	public void create() {
		
		manager = new AssetManager();
		batch = new SpriteBatch();
		viewport = new FitViewport(V_WIDTH,V_HEIGHT);
		
		manager.load("Player/arrow.png", Texture.class);
		manager.load("Player/hookshot.png", Texture.class);
        manager.load("Player/LinkAtlas.png", Texture.class);
		manager.load("Player/LinkAtlasSword.png", Texture.class);
		manager.load("Enemies/Arqueros/arrow2.png",Texture.class);
		manager.load("Enemies/Lynel/ball_fire.png",Texture.class);
		manager.load("Enemies/enemies_atlas.png",Texture.class);
		manager.load("Map/minimap.png", Texture.class);
		manager.load("GamePad/Button_Sword.png", Texture.class);
		manager.load("GamePad/Button_Shield.png", Texture.class);
		manager.load("GamePad/Button_Z.png", Texture.class);
		manager.load("GamePad/Button_Y.png", Texture.class);
		manager.load("GamePad/Button_Save.png", Texture.class);
		manager.load("GamePad/background.png", Texture.class);
		manager.load("GamePad/knob.png", Texture.class);
		manager.load("Hud/small_keys.png", Texture.class);
		manager.load("Hud/item_arrow.png", Texture.class);
		manager.load("Hud/magic_bar.png", Texture.class);
		manager.load("Hud/O'clock.png", Texture.class);
		manager.load("Hud/arrow_icon.png", Texture.class);
		manager.load("Hud/piece_of_heart_icon.png", Texture.class);
		manager.load("Enemies/enemy_die.png", Texture.class);
		manager.load("Sound/overworld.mp3", Music.class);
		manager.load("Sound/roll.wav", Sound.class);
		manager.load("Sound/arrow_hit.wav", Sound.class);
		manager.load("Sound/bow_pull.wav", Sound.class);
		manager.load("Sound/bow_twang.wav", Sound.class);
		manager.load("Sound/hookshot_set.wav", Sound.class);
		manager.load("Sound/secret.ogg", Music.class);
		manager.load("Sound/hookshot_fire.wav", Music.class);
		manager.load("Sound/shield_out.wav", Sound.class);
		manager.load("Sound/Sword1.wav", Sound.class);
		manager.load("background.png", Texture.class);
		manager.load("dialog_box.png", Texture.class);
		manager.load("box.png", Texture.class);
		manager.load("icon_load.png", Texture.class);
		
        //manager.finishLoading();
		setScreen(new LoadScreen(this));
	}

	public void finishLoading(){
		setScreen(new StartingScreen(this));
	}
	
	public void setToSelectMatch(){
		setScreen(new SelectMatch(this));
	}
	
	public void setGameRugleScreen(){
		setScreen(new RugleScreen(this));
	}
	
	public void setGamePlayScreen(){
		setScreen(new GameScreen(this));
	}
	
	public void setGameOverScreen(){
		setScreen(new GameOverScreen(this));
	}
	
	public void setEndingScreen(){
		setScreen(new EndingScreen(this));
	}
	
	public SpriteBatch getDrawer()
	{
		return batch;
	}

	public FitViewport getViewport(){
		return viewport;
	}
	
	@Override
	public void dispose()
	{
		manager.dispose();
	}
	
}
