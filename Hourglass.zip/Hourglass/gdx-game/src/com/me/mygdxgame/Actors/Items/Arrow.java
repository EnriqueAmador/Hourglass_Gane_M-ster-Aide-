package com.me.mygdxgame.Actors.Items;

import com.me.mygdxgame.Actors.Heroe;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.audio.*;
import com.me.mygdxgame.*;

public class Arrow extends Actor
{
	private int setX,setY;
	private int cutterX,cutterY;
	private int Time = -10;
	private int Index = 0;
	private int justColapse;
	public int timeClear;
	private boolean destroyed;
	public String direction;
	public static String dir;
	public static int rowTiled,colTiled,tileSize;
	private TiledMapTileLayer layer;
	
	public Arrow(){}
	
	public Arrow(TiledMap map,String direction,int setX,int setY){
		this.setX = setX;
		this.setY = setY;
		dir = direction;
		this.direction = direction;
		tileSize = map.getProperties().get("tilewidth", Integer.class);
		layer = (TiledMapTileLayer) map.getLayers().get(0);
	}
	
	public void updateArrow(com.me.mygdxgame.Hourglass game,Heroe player){
		rowTiled = this.setX / tileSize;
		colTiled = this.setY / tileSize;
		player.directionArrow = direction;
		destroyed = layer.getCell(rowTiled,colTiled).getTile().getProperties().containsKey("blocked");
		switch (direction){
			case "Right":
				if (!layer.getCell(rowTiled, colTiled).getTile().getProperties()
					.containsKey("blocked")){
					cutterX = 0;
					cutterY = 0;
					Time = -10;
					Index = 0;
					timeClear = 0;
					setX += 5;
					return;} 
					else{
						setFinishAnim(game);
						colTiled = rowTiled = 0;
						cutterY = 0;
					}
			break;
			case "Up":
				if (!layer.getCell(rowTiled, colTiled).getTile().getProperties()
					.containsKey("blocked")){
					cutterX = 0;
					cutterY = 16;
					Time = -10;
					Index = 0;
					timeClear = 0;
					setY += 3;
				    return;}
				else{
					setFinishAnim(game);
					colTiled = rowTiled = 0;
					cutterY = 16;
				}
		    break;
	      case "Down":
				if (!layer.getCell(rowTiled, colTiled).getTile().getProperties()
					.containsKey("blocked")){
					cutterX = 0;
					cutterY = 48;
					Time = -10;
					Index = 0;
					timeClear = 0;
					setY -= 3;
					return;}
				else{
					setFinishAnim(game);
					colTiled = rowTiled = 0;
					cutterY = 48;
				}
				break;
			case "Left":
				if (!layer.getCell(rowTiled, colTiled).getTile().getProperties()
					.containsKey("blocked")){
					cutterX = 0;
					cutterY = 32;
					Time = -10;
					Index = 0;
					timeClear = 0;
					setX -= 3;
					return;}
				else{
					setFinishAnim(game);
					colTiled = rowTiled = 0;
					cutterY = 32;
				}
				break;
				}
		
	}
	
	private void setFinishAnim(com.me.mygdxgame.Hourglass game){
		Time++;
		if(cutterX == 128){
			cutterX = 128;
			justColapse = 0;
			timeClear++;
			return;}
		while(Time == Index){
			Index += 8;
			cutterX += 16;
			justColapse++;
			if(justColapse == 1)
			game.manager.get("Sound/arrow_hit.wav", Sound.class).play();
			break;}
	}
	
	public TextureRegion drawArrow(com.me.mygdxgame.Hourglass game){
		return new TextureRegion(game.manager.get("Player/arrow.png",Texture.class),cutterX,cutterY,16,16);
	}
	
	public void Update(SpriteBatch batch,com.me.mygdxgame.Hourglass game){
		game.getDrawer().begin();
		game.getDrawer().draw(drawArrow(game),setX,setY,16,7);
		game.getDrawer().end();
	}
	
	public void dispose(Hourglass game){
		drawArrow(game).getTexture().dispose();
	}
	
	public boolean getDestroyed(){
		return destroyed;
	}
}
