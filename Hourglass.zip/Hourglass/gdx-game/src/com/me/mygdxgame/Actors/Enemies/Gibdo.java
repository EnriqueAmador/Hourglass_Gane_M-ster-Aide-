package com.me.mygdxgame.Actors.Enemies;

import com.me.mygdxgame.Systems.Animation.*;
import com.me.mygdxgame.Systems.Entity.*;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.graphics.*;
import com.me.mygdxgame.Screen.*;

public class Gibdo extends EnemySystem
{
	private TextureRegion[] walkingDown,walkingLeft,walkingRight,walkingUp;
	
	public Gibdo(GameScreen screen,TiledMap map,String iD,boolean item,int i1,int i2){
		super(screen,map,iD,item,i1,i2);
		scrY = scrX = 24;
		walkingDown = sprite.atlas(2,118,629,36,39,false,false);
		walkingLeft = sprite.atlas(2,144,629,36,39,false,false);
		walkingRight = sprite.atlas(2,144,629,36,39,true,false);
		walkingUp = sprite.atlas(2,197,629,36,39,false,false);
		
		WALKING_DOWN = new Animation(0.14f,walkingDown);
		WALKING_LEFT = new Animation(0.14f,walkingLeft);
		WALKING_RIGHT = new Animation(0.14f,walkingRight);
		WALKING_UP = new Animation(0.14f,walkingUp);
		
        moveSpeed = 1;
	}

}
