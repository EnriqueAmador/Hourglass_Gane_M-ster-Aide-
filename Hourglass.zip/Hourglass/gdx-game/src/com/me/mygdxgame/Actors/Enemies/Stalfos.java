package com.me.mygdxgame.Actors.Enemies;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.maps.tiled.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.me.mygdxgame.Systems.Entity.*;
import com.badlogic.gdx.graphics.*;
import com.me.mygdxgame.Screen.*;

public class Stalfos extends EnemySystem
{
	protected TextureRegion current;
	protected Animation run, run_left, run_right, run_up;
	protected float time;
	protected boolean detected = true;
	protected TextureRegion[] overlaps, leftFrames, rightFrames, upFrames;
	
	public Stalfos(GameScreen screen,TiledMap map,String iD,boolean item,int i1,int i2){
		super(screen,map,iD,item,i1,i2);
		scrY = scrX = 18;
		overlaps = Animation_Graphics.CreateAnimation("Enemies/Stalfos/Stalfos.png", 3, 1);
		rightFrames = Animation_Graphics.CreateAnimation("Enemies/Stalfos/Stalfos_Right.png", 3, 1);
		leftFrames = Animation_Graphics.CreateAnimation("Enemies/Stalfos/Stalfos_Left.png", 3, 1);
		upFrames = Animation_Graphics.CreateAnimation("Enemies/Stalfos/Stalfos_Up.png", 3, 1);
	
		WALKING_DOWN = new Animation(0.09f, overlaps);
		WALKING_RIGHT = new Animation(0.09f, rightFrames);
		WALKING_LEFT = new Animation(0.09f, leftFrames);
		WALKING_UP = new Animation(0.09f, upFrames);
	
        moveSpeed = 1;
	}

}
