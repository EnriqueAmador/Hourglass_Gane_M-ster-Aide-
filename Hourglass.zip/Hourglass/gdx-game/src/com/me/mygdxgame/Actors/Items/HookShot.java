package com.me.mygdxgame.Actors.Items;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.audio.*;
import com.me.mygdxgame.*;
import com.me.mygdxgame.Actors.*;

public class HookShot extends Actor
{
	private String angle;
	public int setX,setY;
	private int cutterX;
	private final int cutterY = 0;
	
	public HookShot(){}
	
	public HookShot(TiledMap map,String angle,int setX,int setY){
		this.setX = setX;
		this.setY = setY;
		this.angle = angle;
	}
	
	public void updateHook(com.me.mygdxgame.Hourglass game,Heroe player){
		switch(angle){
			case "ball":
				cutterX = 64;
				break;
			case "peakUp":
				cutterX = 16;
				player.bodyPickHShot().x = setX;
				player.bodyPickHShot().y = setY;
				player.bodyPickHShot().setSize(16,16);
				break;
			case "peakDown":
				cutterX = 48;
				player.bodyPickHShot().x = setX;
				player.bodyPickHShot().y = setY;
				player.bodyPickHShot().setSize(16,16);
				break;
			case "peakRight":
				cutterX = 0;
				player.bodyPickHShot().x = setX;
				player.bodyPickHShot().y = setY;
				player.bodyPickHShot().setSize(16,16);
				break;
			case "peakLeft":
				cutterX = 32;
				player.bodyPickHShot().x = setX;
				player.bodyPickHShot().y = setY;
				player.bodyPickHShot().setSize(16,16);
				break;
		}

	}
	
	public TextureRegion drawHookShot(com.me.mygdxgame.Hourglass game){
		return new TextureRegion(game.manager.get("Player/hookshot.png",Texture.class),cutterX,cutterY,16,16);
	}
	public void drawHook(SpriteBatch batch,com.me.mygdxgame.Hourglass game){
		game.getDrawer().begin();
		game.getDrawer().draw(drawHookShot(game),setX,setY,16,10);
		game.getDrawer().end();
	}
	
	public void dispose(Hourglass game){
		drawHookShot(game).getTexture().dispose();
	}
}
