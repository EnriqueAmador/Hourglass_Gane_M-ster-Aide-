package com.me.mygdxgame.Actors;

import org.enriqu.ta.SYSTEMS.Input.Event;

import com.me.mygdxgame.Systems.Entity.Base_Player;
import com.me.mygdxgame.Actors.Items.Arrow;
import com.me.mygdxgame.Actors.Items.HookShot;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.me.mygdxgame.*;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.graphics.*;
import com.me.mygdxgame.Systems.Hud.Hud;
import com.me.mygdxgame.Systems.Entity.*;
import com.badlogic.gdx.graphics.g2d.*;
import java.util.*;
import com.me.mygdxgame.Systems.Camera.*;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.me.mygdxgame.Systems.Input.*;
import com.me.mygdxgame.Screen.*;

public class Heroe extends Base_Player
{
	public enum State{
		IdlingUp,
		IdlingDown,
		IdlingLeft,
		IdlingRight,
		ShieldUp,
		ShieldDown,
		ShieldLeft,
		ShieldRight,
		BowUp,
		BowDown,
		BowLeft,
		BowRight,
		HookShootUp,
		HookShootDown,
		HookShootLeft,
		HookShootRight,
		RoamUp,
		RoamDown,
		RoamLeft,
		RoamRight,
		SwordUp,
		SwordDown,
		SwordLeft,
		SwordRight,
		Death;
	}
	
	private enum Smash{
		smashEnemy,
		smashFalse;
	}
	
	public State state;
	private Smash smash;
	public int timeHookShot;
	public int resX,resY,rePosX,resPosY;
	public Array<Arrow>arrow;
	public Array<HookShot>hookShot;
	private Array<Rectangle>bodyArrow;
	public String way = "Right";
	public String angle;
	public String directionArrow;
	private String texture;
	public boolean resetIndex;
	public boolean setShield;
	public boolean setSword;
	private boolean setGameOverScreen;
	private int largeIndex;
	private int Time = -10,time;
	private int timeReverse = 10;
	private int time_reverse = 0;
	private int Index = 0;
	private int removeIndex = 6;
	private int width,height;
	private int disX,setX,disY,setY;
	private float timeAnim;
	private Rectangle bodyDef;
	private Rectangle shield;
	private Rectangle sword;
	private Rectangle reBodyArrow;
	private Rectangle hShot;
	private TextureRegion[] die;
	private TextureRegion current;
	private Animation_Graphics death;
	private Animation dead;
	private SpriteBatch batch;

	private TiledMap map;
	
	public Heroe(TiledMap map,int setX,int setY)
	{
		super(map,setX,setY);
		this.map = map;
		batch = new SpriteBatch();
		bodyDef = new Rectangle((int)getX(),(int)getY(),16,16);
		shield = new Rectangle((int)getX(),(int)getY(),16,8);
		sword = new Rectangle((int)getX(),(int)getY()-6,18,8);
		bodyArrow = new Array<Rectangle>();
		reBodyArrow = new Rectangle();
		hShot = new Rectangle();
		texture = "Player/LinkAtlas.png";
		resX = resY = 16;
		rePosX = 0;
		arrow = new Array<Arrow>(10);
		hookShot = new Array<HookShot>();
		death = new Animation_Graphics("Player/LinkAtlas.png");
		die = death.atlas(3,-20,420,20,29);
		dead = new Animation(2.9999999f,die);
		current = new TextureRegion();
		moveSpeed = 1;
	}
	
	public void updatePlayer()
	{
		getUpdatePosition();
		bodyDef.x = (int)getX();
		bodyDef.y = (int)getY();
	
		switch(smash){
			case smashEnemy:
				batch.setColor(Color.RED);
				break;
			case smashFalse:
				batch.setColor(Color.WHITE);
				break;
		}
		if (x == xdest && y == ydest) 
			up = down = left = right = moving = false;
	}
	
	public void updateDrawer(){
		batch().begin();
		batch().draw(current,(int)getX() - rePosX,(int)getY() - resPosY,resX,resY);
		batch().end();
	}
	
	public void drawPlayer(GameScreen screen,Hud hud,Hourglass game,Input_GamePad pad){
		if(hud.getHeart() <= 0){
			timeAnim += 0.1f;
			current = dead.getKeyFrame(timeAnim,false);
			pad.nameKey = "null";
			if(dead.isAnimationFinished(timeAnim))
			setGameOverScreen = true;
		}else current = getFrame(game.manager.get(texture,Texture.class),width,height);
	}
	
	public boolean getGameOverScreen(){
		return setGameOverScreen;
	}
	
	/*public TextureRegion drawPlayer(com.me.mygdxgame.Hourglass game){
		return (state == state.Death)?current
		: getFrame(game.manager.get(texture,Texture.class),width,height);
	}*/
	
	public void setTexture(String texture,int width,int height){
		this.texture = texture;
		this.width = width;
		this.height = height;
	}
	
	public void stateEffect(String texture,int width,int height)
	{
		this.texture = texture;
		this.width = width;
		this.height = height;
		
		switch(state){
			case IdlingUp:
				drawTexture(0,504);
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				setBodyUp();
				//statePlayer = "StopUp";
				break;
			case IdlingDown:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				setBodyDown();
				drawFrame(0,110,15,160,true,false,false);
				//statePlayer = "StopDown";
				break;
			case IdlingLeft:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				setBodyLeft();
				drawFrame(0,252,15,100,true,false,false);
				//statePlayer = "StopLeft";
				break;
			case IdlingRight:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				setBodyRight();
				drawFrame(0,252,15,100,true,true,false);
				//statePlayer = "StopRight";
				break;
			case RoamUp:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,29,8,120,false,false,false);
				//statePlayer = "StopUp";
				break;
			case RoamDown:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,168,8,140,false,false,false);
				//statePlayer = "StopDown";
				break;
			case RoamLeft:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,334,8,160,false,false,false);
				//statePlayer = "StopLeft";
				break;
			case RoamRight:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,334,8,160,false,true,false);
				//statePlayer = "StopRight";
				break;
			case BowLeft:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,364,8,100,false,false,false);
				//statePlayer = "StopLeft";
				break;
			case BowRight:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,364,6,100,false,true,false);
				//statePlayer = "StopRight";
				break;
			case BowDown:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,224,8,100,false,false,false);
				//statePlayer = "StopDown";
				break;
			case BowUp:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,84,8,100,false,false,false);
				break;
			case ShieldUp:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY()+16;
				drawFrame(0,54,7,80,false,false,false);
				//statePlayer = "StopUp";
				break;
			case ShieldDown:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY()-16;
				drawFrame(0,194,6,80,false,false,false);
				//statePlayer = "StopDown";
				break;
			case ShieldLeft:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX()-16;
				shield.y = (int)getY();
				drawFrame(0,307,8,40,false,false,false);
				//statePlayer = "StopLeft";
				break;
			case ShieldRight:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX()+16;
				shield.y = (int)getY();
				drawFrame(0,307,8,40,false,true,false);
				//statePlayer = "StopRight";
				break;
			case HookShootUp:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,534,8,80,false,false,false);
				//statePlayer = "StopUp";
				break;
			case HookShootDown:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,561,8,100,false,false,false);
				//statePlayer = "StopDown";
				break;
			case HookShootLeft:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,590,8,80,false,false,false);
				//statePlayer = "StopLeft";
				break;
			case HookShootRight:
				resX = resY = 16;
				resPosY = rePosX = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,590,8,80,false,true,false);
				//statePlayer = "StopRight";
				break;
			case SwordUp:
				resX = 32;resY = 20;
				rePosX = 10;
				resPosY = 0;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(40,0,3,270,false,false,false);
				//statePlayer = "StopUp";
				break;
			case SwordDown:
				resX = 34;resY = 19;
				rePosX = 7;
				resPosY = 4;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,34,3,270,false,false,false);
				//statePlayer = "StopDown";
				break;
			case SwordLeft:
				resX = 34;resY = 19;
				rePosX = 10;
				resPosY = 4;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,68,3,270,false,false,false);
				//statePlayer = "StopLeft";
				break;
			case SwordRight:
				resX = 34;resY = 19;
				rePosX = 8;
				resPosY = 4;
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,68,3,270,false,true,false);
				//statePlayer = "StopRight";
				break;
			/*case Death:
				drawFrame(0,420,20,40,false,false,false);
				break;*/
			default:
				shield.x = (int)getX();
				shield.y = (int)getY();
				drawFrame(0,252,15,100,true,true,false);
				break;
		}
	}
	
	public String getState(){
		return statePlayer;
	}
	
	public void setBodyDown(){
		sword.set((int)getX(),(int)getY()-6,20,13);
	}
	
	public void setBodyUp(){
		sword.set((int)getX(),(int)getY()+6,20,13);
	}
	
	public void setBodyLeft(){
		sword.set((int)getX()-6,(int)getY(),13,14);
	}
	
	public void setBodyRight(){
		sword.set((int)getX()+6,(int)getY(),13,14);
	}
	
	public void takeHshot(){
		bodyPickHShot().x = 0;
		bodyPickHShot().y = 0;
	}
	
	/*public void die(Hud hud,Input_GamePad pad){
		timeAnim = Gdx.graphics.getDeltaTime();
		if(hud.getHeart() == 0)
			state = state.Death;
			current = dead.getKeyFrame(timeAnim,true);
	}*/
	
	public void shootArrow(com.me.mygdxgame.Systems.Hud.Hud hud,int x,int y){
		largeIndex++;
		if (largeIndex == 1 && hud.getStateArrow() + hud.numA > 0){
			arrow.add(new Arrow(map, way, (int)getX() + x, (int)getY() + y));
			bodyArrow.add(new Rectangle((int)getX()+x,(int)getY()+y,16,16));
		}return;
	}
	
	public void addHookShotV(String type,int setHeight,int setReHeight,int posY){
		Time++;
		removeHookShot();
		if(Index == 120)
		    return;
		angle = (Index == 100)?type:"ball";
		while(Time == time){
		time += 6;
		setY = (Index == 0)?(int)getY():setY;
		disY += (Index == 0)?setHeight:setReHeight;
			Index += 20;
			hookShot.add(new HookShot(map,angle,(int)getX()+posY,setY + disY));
		break;}
	}
	
	public void addHookShotH(String type,int setWitdh,int setReWitdh,int posX){
		Time++;
		removeHookShot();
		if(Index == 120)
		    return;
		angle = (Index == 100)?type:"ball";
		while(Time == time){
			time += 6;
			setX = (Index == 0)?(int)getX():setX;
			disX += (Index == 0)?setWitdh:setReWitdh;
			Index += 20;
			hookShot.add(new HookShot(map,angle,setX + disX,(int)getY() + posX));
			break;}
	}
	
	public void removeHookShot(){
		if(hookShot.size == 0)
			return;
		if(Index == 120){
			timeReverse--;
			while(timeReverse == time_reverse){
				time_reverse -= 6;
				removeIndex--;
				if(removeIndex == 0)
					resetIndex = true;
				hookShot.removeIndex(removeIndex);
			}
		}
	}
	
	public void resize(){
		Time = -10;
		time = 0;
		timeReverse = 10;
		time_reverse = 0;
		Index = 0;
		setX = setY = 0;
		disX = disY = 0;
		removeIndex = 6;
	}
	
	public void resetIndex(){
		largeIndex = 0;
	}
	
	public void shoot(com.me.mygdxgame.Hourglass game){
		for(HookShot hookshot : hookShot){
			hookshot.updateHook(game,this);
			hookshot.drawHook(game.getDrawer(),game);
		}
		
		for(Arrow arroW : arrow){
			arroW.updateArrow(game,this);
			arroW.Update(game.getDrawer(),game);
			for(Rectangle bodyArrow : bodyDefArrow()){
				switch(directionArrow){
					case "Right":
						bodyArrow.x += 5;
						bodyArrow.y = (int)getY();
						reBodyArrow.set(bodyArrow);
						break;
					case "Up":
						bodyArrow.y += 3;
						bodyArrow.x = (int)getX();
						reBodyArrow.set(bodyArrow);
						break;
					case "Down":
						bodyArrow.y -= 3;
						bodyArrow.x = (int)getX();
						reBodyArrow.set(bodyArrow);
						break;
					case "Left":
						bodyArrow.x -= 3;
						bodyArrow.y = (int)getY();
						reBodyArrow.set(bodyArrow);
						break;
				}
				
				if(arroW.getDestroyed()){
					reBodyArrow.set(0,0,16,16);
					bodyDefArrow().removeValue(bodyArrow,true);
					return;
				}
				
				}
			if(arroW.timeClear >= 180){
				arrow.removeValue(arroW,true);
				return;
			}
		}
		
	}
	
	public void disposeAllTexture(Hourglass game){
		//drawPlayer(game).getTexture().dispose();
		HookShot hs = new HookShot();
		hs.dispose(game);
		Arrow arrow = new Arrow();
		arrow.dispose(game);
	}
	
	public void minPosition(){
		switch(state){
			case IdlingUp:
				setDown();
				break;
			case IdlingDown:
				setUp();
				break;
			case IdlingLeft:
				setRight();
				break;
			case IdlingRight:
				setLeft();
				break;
		}
	}
	
   public void RED(){
	   smash = smash.smashEnemy;
   }
   
   public void WHITE(){
	   smash = smash.smashFalse;
   }
   
	public SpriteBatch batch(){
		return batch;
	}
	
	public Rectangle bodyDefPlayer(){
		return bodyDef;
	}
	
	public Rectangle bodyShield(){
		return shield;
	}
	
	public Rectangle bodySword(){
		return sword;
	}
	
	public Rectangle bodyPickHShot(){
		return hShot;
	}
	
	public Rectangle reBodyDefArrow(){
		return reBodyArrow;
	}
	
	public Array<Rectangle> bodyDefArrow(){
		return bodyArrow;
	}
	
	/**
	 * Devuelve el valor del eje X del jugador en flotante para ser registrado
	 * en la projeción de la camara
	 */
	public float getX()
    {
        return x;
    }

	/**
	 * Devuelve el valor del eje Y del jugador en flotante para ser registrado
	 * en la projeción de la camara
	 */
    public float getY()
    {
        return y;
    }

}

