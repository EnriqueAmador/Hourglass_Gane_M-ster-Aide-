package com.me.mygdxgame.Actors.Enemies;

import com.me.mygdxgame.Systems.Entity.EnemySystem;

import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.graphics.g2d.*;
import com.me.mygdxgame.Systems.Animation.*;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.*;
import com.badlogic.gdx.utils.*;
import com.badlogic.gdx.math.*;
import com.me.mygdxgame.*;
import com.me.mygdxgame.Actors.*;
import com.me.mygdxgame.Screen.*;

public class Arqueros extends EnemySystem
{
	protected TextureRegion[] overlaps, rightFrames, leftFrames, upFrames;
	private int clearArrow,lap = 1;
	private int cutX,cutY;
	private String dir;
	private Array<BlueArrow>arrowList = new Array<BlueArrow>();
	private TiledMap map;
	
	public Arqueros(GameScreen screen,TiledMap map,String iD,boolean item,int i1,int i2){
		super(screen,map,iD,item,i1,i2);
		this.map = map;
		scrY = scrX = 18;
		overlaps = Animation_Graphics.CreateAnimation("Enemies/Arqueros/Arqueros.png", 3, 1);
		rightFrames = Animation_Graphics.CreateAnimation("Enemies/Arqueros/Arquero_Right.png", 3, 1);
		leftFrames = Animation_Graphics.CreateAnimation("Enemies/Arqueros/Arquero_Left.png", 3, 1);
		upFrames = Animation_Graphics.CreateAnimation("Enemies/Arqueros/Arquero_Up.png", 3, 1);
	
	    WALKING_DOWN = new Animation(0.14f, overlaps);
		WALKING_RIGHT = new Animation(0.14f, rightFrames);
		WALKING_LEFT = new Animation(0.14f, leftFrames);
		WALKING_UP = new Animation(0.14f, upFrames);
		
        moveSpeed = 1;

	}

	@Override
	protected void addElement(Hourglass game){
		dir = enemies_State;
		switch(enemies_State){
			case "Right":
				clearArrow++;
				cutX = 0;
				cutY = 0;
				break;
			case "Up":
				clearArrow++;
				cutX = 0;
				cutY = 16;
				break;
			case "Left":
				clearArrow++;
				cutX = 0;
				cutY = 32;
				break;
			case "Down":
				clearArrow++;
				cutX = 0;
				cutY = 48;
				break;
			default:
			clearArrow = 0;
			lap = 1;
		}
		if((clearArrow == lap)&&(changeState != 30)){
			lap += 50;
			arrowList.add(new BlueArrow(map,dir,(int)getX() + 5,(int)getY() + 5));
			bodyDefItem().add(new Rectangle((int)getX()+5,(int)getY()+5,16,16));
		}
	}

	@Override
	protected void renderElement(Hourglass game,Heroe player)
	{
		for(BlueArrow arrow : arrowList){
			arrow.Update(game);
			for(Rectangle bodyItems : bodyDefItem()){
				switch(enemies_State){
					case "Right":
						bodyItems.y = (int)getY();
						bodyItems.x += 3;
						break;
					case "Left":
						bodyItems.y = (int)getY();
						bodyItems.x -= 3;
						break;
					case "Up":
						bodyItems.x = (int)getX();
						bodyItems.y += 3;
						break;
					case "Down":
						bodyItems.x = (int)getX();
						bodyItems.y -= 3;
						break;
				}
			bodyItemDetected = (bodyItems.overlaps(player.bodyDefPlayer()))
			? true : false;
			if(arrow.removeArrow()||getProct(player)){
				arrowList.removeValue(arrow,true);
				bodyDefItem().removeValue(bodyItems,true);
				}
		}
		}

	}
	
	class BlueArrow {

		int cutterX;
		int cutterY;
		int setY;
		int setX;
		int row,col;
		String direction;

		public BlueArrow(TiledMap map,String direction,int setX,int setY){
			this.setX = setX;
			this.setY = setY;
			this.direction = direction;
			cutterX = cutX;
			cutterY = cutY;
		}

		public TextureRegion drawArrow(com.me.mygdxgame.Hourglass game){
			return new TextureRegion(game.manager.get("Enemies/Arqueros/arrow2.png",Texture.class),cutterX,cutterY,16,16);
		}

		public void Update(com.me.mygdxgame.Hourglass game){
			switch(direction){
				case "Right":
					setX += 3;
					break;
				case "Left":
					setX -= 3;
					break;
				case "Up":
					setY += 3;
					break;
				case "Down":
					setY -= 3;
					break;
			}
			game.getDrawer().begin();
			game.getDrawer().draw(drawArrow(game),setX,setY,16,7);
			game.getDrawer().end();
		}
		
		public boolean removeArrow(){
			row = this.setX/tileSize;
			col = this.setY/tileSize;
			return layer.getCell(row,col).getTile().getProperties().containsKey("blocked") ? true : false;
		}
		
		public int getX(){
			return setX;
		}
		
		public int getY(){
			return setY;
		}
	}
}
